import { Injectable, NgZone, OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';

export interface AlgorithmInfo {
  id: string;
  name: string;
  description: string;
  mode: 'async' | 'sync';
  metadata: string;
}

export interface WsMessage<T = any> {
  type: string;
  payload: T;
  message: string;
}

export interface Job {
  id: string;
  job_type: string;
  request: any;
  status: 'created' | 'running' | 'completed' | 'failed';
  result: any;
  error: string | null;
  created_at: string;
  updated_at: string;
}

@Injectable({
  providedIn: 'root'
})
export class PlannerService implements OnDestroy {
  private apiUrl = 'http://localhost:8000/api/planner';
  private wsUrl = 'ws://localhost:8000/api/planner/ws';
  private ws: WebSocket | null = null;
  private jobUpdates$ = new Subject<Job>();

  constructor(private http: HttpClient, private ngZone: NgZone) {}

  getAlgorithms(): Observable<AlgorithmInfo[]> {
    return this.http.get<AlgorithmInfo[]>(`${this.apiUrl}/algorithms`);
  }

  getJobs(): Observable<Job[]> {
    return this.http.get<Job[]>(`${this.apiUrl}/jobs`);
  }

  getJob(id: string): Observable<Job> {
    return this.http.get<Job>(`${this.apiUrl}/jobs/${id}`);
  }

  createJob(algorithm: string, request: any = {}): Observable<Job> {
    return this.http.post<Job>(`${this.apiUrl}/jobs`, { algorithm, request });
  }

  /** Run a synchronous algorithm – returns the result directly, no job created */
  runSync(algorithm: string, request: any = {}): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/run`, { algorithm, request });
  }

  /** Connect to WebSocket for real-time job updates */
  connectWebSocket(): Observable<Job> {
    if (!this.ws || this.ws.readyState === WebSocket.CLOSED) {
      this.ws = new WebSocket(this.wsUrl);

      this.ws.onmessage = (event) => {
        const msg: WsMessage = JSON.parse(event.data);
        if (msg.type === 'analysis') {
          const job: Job = msg.payload;
          this.ngZone.run(() => this.jobUpdates$.next(job));
        }
      };

      this.ws.onclose = () => {
        // Reconnect after 3 seconds
        setTimeout(() => this.connectWebSocket(), 3000);
      };

      this.ws.onerror = () => {
        this.ws?.close();
      };

      this.ws.onopen = () => {
        // Send a keep-alive ping every 30s
        const ping = setInterval(() => {
          if (this.ws?.readyState === WebSocket.OPEN) {
            this.ws.send('ping');
          } else {
            clearInterval(ping);
          }
        }, 30000);
      };
    }
    return this.jobUpdates$.asObservable();
  }

  disconnectWebSocket(): void {
    this.ws?.close();
    this.ws = null;
  }

  ngOnDestroy(): void {
    this.disconnectWebSocket();
    this.jobUpdates$.complete();
  }
}
