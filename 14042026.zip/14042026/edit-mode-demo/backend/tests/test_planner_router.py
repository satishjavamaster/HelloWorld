"""Tests for the planner router endpoints.

Uses a standalone FastAPI app with only the planner router mounted,
avoiding the full app import chain (which pulls in neo4j).
"""

import asyncio
import pytest
import pytest_asyncio
from unittest.mock import patch, AsyncMock
from fastapi import FastAPI
from httpx import AsyncClient, ASGITransport
from starlette.testclient import TestClient

from app.services.job_manager import JobManager, JobStatus
from app.routers.planner import router


_app = FastAPI()
_app.include_router(router, prefix="/api/planner")


@pytest_asyncio.fixture
async def fresh_job_manager():
    mgr = JobManager()
    with patch("app.routers.planner.job_manager", mgr), \
         patch("app.services.algorithms.job_manager", mgr):
        yield mgr


@pytest_asyncio.fixture
async def client(fresh_job_manager):
    transport = ASGITransport(app=_app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac


class TestCreateJob:
    @pytest.mark.asyncio
    async def test_create_job_returns_201(self, client, fresh_job_manager):
        with patch("app.routers.planner.run_algorithm", new_callable=AsyncMock):
            resp = await client.post("/api/planner/jobs", json={"algorithm": "shortest_path"})
        assert resp.status_code == 201
        data = resp.json()
        assert data["status"] == "created"
        assert data["job_type"] == "shortest_path"

    @pytest.mark.asyncio
    async def test_create_job_stores_task(self, client, fresh_job_manager):
        with patch("app.routers.planner.run_algorithm", new_callable=AsyncMock):
            resp = await client.post("/api/planner/jobs", json={"algorithm": "shortest_path"})
        job_id = resp.json()["id"]
        # Task should be tracked (may already be done since mock is instant)
        job = fresh_job_manager.get_job(job_id)
        assert job is not None

    @pytest.mark.asyncio
    async def test_create_job_unknown_algorithm(self, client):
        resp = await client.post("/api/planner/jobs", json={"algorithm": "bogus"})
        assert resp.status_code == 400

    @pytest.mark.asyncio
    async def test_create_job_with_request(self, client, fresh_job_manager):
        with patch("app.routers.planner.run_algorithm", new_callable=AsyncMock):
            resp = await client.post("/api/planner/jobs", json={
                "algorithm": "shortest_path",
                "request": {"source": "A", "target": "B"},
            })
        assert resp.status_code == 201
        assert resp.json()["request"] == {"source": "A", "target": "B"}

    @pytest.mark.asyncio
    async def test_create_job_default_request(self, client, fresh_job_manager):
        with patch("app.routers.planner.run_algorithm", new_callable=AsyncMock):
            resp = await client.post("/api/planner/jobs", json={"algorithm": "pagerank"})
        assert resp.json()["request"] == {}


class TestListJobs:
    @pytest.mark.asyncio
    async def test_list_jobs_empty(self, client):
        resp = await client.get("/api/planner/jobs")
        assert resp.status_code == 200
        assert resp.json() == []

    @pytest.mark.asyncio
    async def test_list_jobs_after_create(self, client, fresh_job_manager):
        with patch("app.routers.planner.run_algorithm", new_callable=AsyncMock):
            await client.post("/api/planner/jobs", json={"algorithm": "shortest_path"})
            await client.post("/api/planner/jobs", json={"algorithm": "pagerank"})
        resp = await client.get("/api/planner/jobs")
        assert len(resp.json()) == 2


class TestGetJob:
    @pytest.mark.asyncio
    async def test_get_job(self, client, fresh_job_manager):
        with patch("app.routers.planner.run_algorithm", new_callable=AsyncMock):
            create_resp = await client.post("/api/planner/jobs", json={"algorithm": "shortest_path"})
        job_id = create_resp.json()["id"]
        resp = await client.get(f"/api/planner/jobs/{job_id}")
        assert resp.status_code == 200
        assert resp.json()["id"] == job_id

    @pytest.mark.asyncio
    async def test_get_job_not_found(self, client):
        resp = await client.get("/api/planner/jobs/nonexistent")
        assert resp.status_code == 404


class TestCancelJob:
    @pytest.mark.asyncio
    async def test_cancel_running_job(self, client, fresh_job_manager):
        async def slow_algo(*args, **kwargs):
            await asyncio.sleep(100)

        with patch("app.routers.planner.run_algorithm", side_effect=slow_algo):
            create_resp = await client.post("/api/planner/jobs", json={"algorithm": "shortest_path"})
        job_id = create_resp.json()["id"]
        await fresh_job_manager.update_status(job_id, JobStatus.RUNNING)

        resp = await client.post(f"/api/planner/jobs/{job_id}/cancel")
        assert resp.status_code == 200
        assert resp.json()["status"] == "cancelled"

    @pytest.mark.asyncio
    async def test_cancel_completed_job_fails(self, client, fresh_job_manager):
        with patch("app.routers.planner.run_algorithm", new_callable=AsyncMock):
            create_resp = await client.post("/api/planner/jobs", json={"algorithm": "shortest_path"})
        job_id = create_resp.json()["id"]
        await fresh_job_manager.update_status(job_id, JobStatus.COMPLETED, result={"done": True})

        resp = await client.post(f"/api/planner/jobs/{job_id}/cancel")
        assert resp.status_code == 400

    @pytest.mark.asyncio
    async def test_cancel_nonexistent_job(self, client):
        resp = await client.post("/api/planner/jobs/nonexistent/cancel")
        assert resp.status_code == 404


class TestAlgorithms:
    @pytest.mark.asyncio
    async def test_list_algorithms(self, client):
        resp = await client.get("/api/planner/algorithms")
        assert resp.status_code == 200
        ids = [a["id"] for a in resp.json()]
        assert "shortest_path" in ids
        assert "node_count" in ids


class TestRunSync:
    @pytest.mark.asyncio
    async def test_run_sync_node_count(self, client):
        resp = await client.post("/api/planner/run", json={"algorithm": "node_count"})
        assert resp.status_code == 200
        assert resp.json()["algorithm"] == "node_count"

    @pytest.mark.asyncio
    async def test_run_sync_unknown(self, client):
        resp = await client.post("/api/planner/run", json={"algorithm": "bogus"})
        assert resp.status_code == 400


class TestWebSocket:
    def test_ws_connect_and_close(self):
        mgr = JobManager()
        with patch("app.routers.planner.job_manager", mgr), \
             patch("app.services.algorithms.job_manager", mgr):
            with TestClient(_app) as tc:
                with tc.websocket_connect("/api/planner/ws") as ws:
                    ws.send_text("ping")
                    ws.close()

    def test_ws_receives_job_update(self):
        mgr = JobManager()
        with patch("app.routers.planner.job_manager", mgr), \
             patch("app.services.algorithms.job_manager", mgr):
            with TestClient(_app) as tc:
                with tc.websocket_connect("/api/planner/ws") as ws:
                    loop = asyncio.new_event_loop()
                    job = loop.run_until_complete(mgr.create_job("shortest_path"))
                    loop.run_until_complete(mgr.update_status(job.id, JobStatus.RUNNING))
                    data = ws.receive_json()
                    assert data["type"] == "analysis"
                    assert data["payload"]["status"] == "running"
                    ws.close()
                    loop.close()

    def test_ws_receives_cancelled_update(self):
        mgr = JobManager()
        with patch("app.routers.planner.job_manager", mgr), \
             patch("app.services.algorithms.job_manager", mgr):
            with TestClient(_app) as tc:
                with tc.websocket_connect("/api/planner/ws") as ws:
                    loop = asyncio.new_event_loop()
                    job = loop.run_until_complete(mgr.create_job("shortest_path"))
                    loop.run_until_complete(mgr.update_status(job.id, JobStatus.CANCELLED))
                    data = ws.receive_json()
                    assert data["type"] == "analysis"
                    assert data["payload"]["status"] == "cancelled"
                    assert "cancelled" in data["message"]
                    ws.close()
                    loop.close()
