"""In-memory job manager for the Planner subsystem.

Provides :class:`JobManager` – a lightweight, in-process store that tracks
algorithm jobs and notifies registered async listeners on every status
change.  This is intentionally simple (no persistence, no external broker)
so that the planner can run without extra infrastructure.

Key classes
-----------
- :class:`JobStatus` – enum of valid statuses (created / running / completed / failed).
- :class:`Job`       – data object representing a single algorithm execution.
- :class:`JobManager` – singleton store + pub-sub notification hub.
"""

import uuid
import asyncio
import logging
from datetime import datetime
from typing import Dict, List, Optional, Callable, Awaitable
from enum import Enum

logger = logging.getLogger(__name__)


class JobStatus(str, Enum):
    CREATED = "created"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class Job:
    """Represents a single algorithm job.

    Attributes:
        id: Auto-generated UUID.
        job_type: Algorithm identifier (e.g. ``shortest_path``).
        request: Algorithm-specific input request.
        status: Current lifecycle state (:class:`JobStatus`).
        result: Output payload set on successful completion.
        error: Error message set on failure.
        created_at: ISO-8601 creation timestamp.
        updated_at: ISO-8601 last-update timestamp.
    """

    def __init__(self, job_type: str, request: Optional[Dict] = None) -> None:
        self.id: str = str(uuid.uuid4())
        self.job_type: str = job_type
        self.request: Dict = request or {}
        self.status: JobStatus = JobStatus.CREATED
        self.result: Optional[Dict] = None
        self.error: Optional[str] = None
        self.created_at: str = datetime.utcnow().isoformat()
        self.updated_at: str = self.created_at

    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "job_type": self.job_type,
            "request": self.request,
            "status": self.status.value,
            "result": self.result,
            "error": self.error,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }


class JobManager:
    """In-memory job manager for tracking async algorithm jobs."""

    def __init__(self) -> None:
        #  jobs is the source of truth for job data (status, result, error, timestamps). It holds the complete lifecycle
        self.jobs: Dict[str, Job] = {}
    #    _tasks only tracks currently running asyncio Tasks. Once a task completes, _on_task_done removes it from _tasks. So finished jobs wouldn't appear if you queried _tasks.
        self._tasks: Dict[str, asyncio.Task] = {}
        self._listeners: List[Callable[[Job], Awaitable[None]]] = []

    async def create_job(self, job_type: str, request: Optional[Dict] = None) -> Job:
        """Create a new job, store it, and return it (status = CREATED).

        Listeners are *not* notified here – the caller returns the job
        via the HTTP response.  Notifications begin with the first
        status transition (CREATED → RUNNING).
        """
        job = Job(job_type=job_type, request=request)
        self.jobs[job.id] = job
        return job

    def run_job(self, job_id: str, coro: asyncio.coroutines) -> asyncio.Task:
        """Wrap a coroutine in a tracked Task for the given job.

        The task is stored so it won't be garbage-collected, and a
        done-callback logs unhandled exceptions and cleans up the
        reference when the task finishes.
        """
        task = asyncio.create_task(coro, name=f"job-{job_id}")
        self._tasks[job_id] = task
        task.add_done_callback(lambda t: self._on_task_done(job_id, t))
        return task

    def _on_task_done(self, job_id: str, task: asyncio.Task) -> None:
        #  Once a task completes, _on_task_done removes it from _tasks. So finished jobs wouldn't appear if you queried _tasks.
        self._tasks.pop(job_id, None)
        if task.cancelled():
            logger.info("Task for job %s was cancelled", job_id)
        elif task.exception() is not None:
            logger.error("Task for job %s raised: %s", job_id, task.exception())

    def cancel_job(self, job_id: str) -> bool:
        """Cancel a running job's task. Returns True if cancellation was requested."""
        task = self._tasks.get(job_id)
        if task and not task.done():
            task.cancel()
            return True
        return False

    def get_active_tasks(self) -> Dict[str, bool]:
        """Return a mapping of job_id → is_running for all tracked tasks."""
        return {jid: not t.done() for jid, t in self._tasks.items()}

    async def update_status(
        self,
        job_id: str,
        status: JobStatus,
        result: Optional[Dict] = None,
        error: Optional[str] = None,
    ) -> None:
        """Transition a job to a new status and notify all listeners."""
        job = self.jobs.get(job_id)
        if not job:
            return
        job.status = status
        job.updated_at = datetime.utcnow().isoformat()
        if result is not None:
            job.result = result
        if error is not None:
            job.error = error
        await self._notify(job)

    def get_job(self, job_id: str) -> Optional[Job]:
        return self.jobs.get(job_id)

    def get_all_jobs(self) -> List[Dict]:
        return [j.to_dict() for j in self.jobs.values()]

    def add_listener(self, callback: Callable[[Job], Awaitable[None]]) -> None:
        self._listeners.append(callback)

    def remove_listener(self, callback: Callable[[Job], Awaitable[None]]) -> None:
        self._listeners = [l for l in self._listeners if l is not callback]

    async def _notify(self, job: Job) -> None:
        logger.info("Notifying %d listener(s) for job %s [%s]", len(self._listeners), job.id, job.status.value)
        for listener in self._listeners:
            try:
                await listener(job)
            except Exception as exc:
                logger.exception("Listener %r failed for job %s: %s", listener, job.id, exc)


job_manager = JobManager()
