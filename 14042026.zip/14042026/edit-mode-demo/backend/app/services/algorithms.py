"""Algorithm implementations for the Planner subsystem.

Provides two execution modes:

- **Async** – long-running algorithms dispatched via :func:`run_algorithm`.
  Each runs as an ``asyncio.Task`` and updates job status through the
  :class:`~app.services.job_manager.JobManager`.
- **Sync** – fast algorithms executed via :func:`run_sync_algorithm` and
  returned directly in the HTTP response (no job created).

Constants
---------
- ``ASYNC_ALGORITHMS`` – set of algorithm IDs valid for ``POST /jobs``.
- ``SYNC_ALGORITHMS``  – set of algorithm IDs valid for ``POST /run``.

Available algorithms
--------------------
Async:
- ``shortest_path``       – simulated shortest-path search.
- ``community_detection`` – simulated community / cluster detection.
- ``pagerank``            – simulated PageRank scoring.

Sync:
- ``node_count``          – count nodes by type.
- ``degree_summary``      – basic degree statistics.
- ``density``             – graph density calculation.
"""

import asyncio
import random
from app.services.job_manager import job_manager, JobStatus

ASYNC_ALGORITHMS = {"shortest_path", "community_detection", "pagerank"}


async def run_algorithm(job_id: str, algorithm: str, request: dict) -> None:
    """Dispatch and execute the requested algorithm.

    Yields to the event loop first so the calling endpoint can finish
    sending the HTTP response (job in ``CREATED`` status) before this
    task transitions the job to ``RUNNING`` and eventually to
    ``COMPLETED`` or ``FAILED``.

    Args:
        job_id: UUID of the job to update.
        algorithm: Algorithm identifier string.
        parameters: Algorithm-specific input dict.
    """
    try:
        # Yield to the event loop so the HTTP response (with status=created)
        # is sent to the client before we broadcast the RUNNING transition.
        await asyncio.sleep(0)
        await job_manager.update_status(job_id, JobStatus.RUNNING)

        if algorithm == "shortest_path":
            result = await _algo_shortest_path(request)
        elif algorithm == "community_detection":
            result = await _algo_community_detection(request)
        elif algorithm == "pagerank":
            result = await _algo_pagerank(request)
        else:
            raise ValueError(f"Unknown algorithm: {algorithm}")

        await job_manager.update_status(job_id, JobStatus.COMPLETED, result=result)
    except asyncio.CancelledError:
        # Cancellation is handled by the cancel endpoint; just stop silently.
        raise
    except Exception as e:
        await job_manager.update_status(job_id, JobStatus.FAILED, error=str(e))


# --------------- stub algorithms (simulate long-running work) ---------------

async def _algo_shortest_path(params: dict) -> dict:
    """Simulated shortest path algorithm.

    Accepts optional ``source`` and ``target`` parameters (default ``A`` / ``G``).
    """
    await asyncio.sleep(5)
    source = params.get("source", "A")
    target = params.get("target", "G")
    intermediate_count = random.randint(1, 4)
    intermediate = [chr(random.randint(66, 70)) for _ in range(intermediate_count)]
    path = [source] + intermediate + [target]
    return {
        "algorithm": "shortest_path",
        "source": source,
        "target": target,
        "path": path,
        "cost": round(random.uniform(1, 20), 2),
        "nodes_explored": random.randint(10, 200),
    }


async def _algo_community_detection(params: dict) -> dict:
    """Simulated community detection algorithm."""
    await asyncio.sleep(8)
    communities = random.randint(2, 6)
    return {
        "algorithm": "community_detection",
        "communities_found": communities,
        "clusters": {f"cluster_{i}": random.randint(3, 15) for i in range(communities)},
    }


async def _algo_pagerank(params: dict) -> dict:
    """Simulated pagerank algorithm."""
    await asyncio.sleep(6)
    return {
        "algorithm": "pagerank",
        "top_nodes": [
            {"node": f"Node_{i}", "score": round(random.uniform(0, 1), 4)}
            for i in range(5)
        ],
        "iterations": random.randint(10, 50),
    }


# --------------- sync algorithms (fast, direct return) ---------------

SYNC_ALGORITHMS = {"node_count", "degree_summary", "density"}


def run_sync_algorithm(algorithm: str, request: dict[str, object]) -> dict[str, object]:
    """Execute a fast, synchronous algorithm and return the result directly.

    Args:
        algorithm: Algorithm identifier string.
        request: Algorithm-specific input dict.

    Raises:
        ValueError: If the algorithm is unknown.
    """
    if algorithm == "node_count":
        return _sync_node_count(request)
    elif algorithm == "degree_summary":
        return _sync_degree_summary(request)
    elif algorithm == "density":
        return _sync_density(request)
    else:
        raise ValueError(f"Unknown sync algorithm: {algorithm}")


def _sync_node_count(params: dict) -> dict:
    """Count nodes by type."""
    return {
        "algorithm": "node_count",
        "employees": random.randint(10, 100),
        "organizations": random.randint(2, 20),
    }


def _sync_degree_summary(params: dict) -> dict:
    """Basic degree statistics."""
    return {
        "algorithm": "degree_summary",
        "min_degree": random.randint(0, 2),
        "max_degree": random.randint(5, 20),
        "avg_degree": round(random.uniform(1, 8), 2),
    }


def _sync_density(params: dict) -> dict:
    """Graph density calculation."""
    return {
        "algorithm": "density",
        "density": round(random.uniform(0.01, 0.5), 4),
        "total_nodes": random.randint(10, 120),
        "total_edges": random.randint(5, 200),
    }
