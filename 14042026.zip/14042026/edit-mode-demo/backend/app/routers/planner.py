"""Planner router – exposes REST and WebSocket endpoints for running
graph algorithms in sync and async modes.

Endpoints
---------
- ``POST /jobs``          – Create and launch a new async algorithm job
                            (returns 201, validates against ``ASYNC_ALGORITHMS``).
- ``GET  /jobs``          – List all jobs (in-memory store).
- ``GET  /jobs/{job_id}`` – Retrieve a single job by ID (404 if missing).
- ``GET  /algorithms``    – List the algorithms available for execution.
- ``POST /run``           – Execute a fast sync algorithm and return the
                            result directly (400 if unknown algorithm).
- ``WS   /ws``            – WebSocket stream that pushes real-time job
                            status updates (created → running → completed / failed).

Error handling
--------------
All error conditions raise :class:`~fastapi.HTTPException` with
appropriate status codes (400 for bad input, 404 for missing resources)
rather than returning 200 with an error payload.

Dependencies
------------
- :mod:`app.services.job_manager` – in-memory job store & listener system.
- :mod:`app.services.algorithms`  – algorithm implementations (sync & async).
"""

import asyncio
import logging
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, HTTPException
from pydantic import BaseModel
from typing import Any, Optional, Dict, List
from app.services.job_manager import job_manager, Job, JobStatus

logger = logging.getLogger(__name__)
from app.services.algorithms import run_algorithm, run_sync_algorithm, ASYNC_ALGORITHMS, SYNC_ALGORITHMS

router = APIRouter()


class SyncRunRequest(BaseModel):
    """Request body for running a synchronous (fast) algorithm.

    Attributes:
        algorithm: Identifier of the sync algorithm
                   (e.g. ``node_count``, ``degree_summary``, ``density``).
        request: Optional dictionary of algorithm-specific request.
    """

    algorithm: str
    request: Optional[Dict] = None


class JobCreate(BaseModel):
    """Request body for creating a new algorithm job.

    Attributes:
        algorithm: Identifier of the algorithm to run
                   (e.g. ``shortest_path``, ``community_detection``, ``pagerank``).
        request: Optional dictionary of algorithm-specific request.
    """

    algorithm: str
    request: Optional[Dict] = None


@router.post("/jobs", status_code=201)
async def create_job(body: JobCreate) -> dict[str, Any]:
    """Create and launch a new algorithm job.

    The job is persisted in the in-memory :class:`JobManager` and the
    algorithm is executed as a fire-and-forget ``asyncio.Task``.  Status
    transitions (created → running → completed/failed) are broadcast to
    all connected WebSocket clients.

    Returns:
        dict: The newly created job record.

    Raises:
        HTTPException: 400 if the algorithm is not recognised.
    """
    if body.algorithm not in ASYNC_ALGORITHMS:
        raise HTTPException(status_code=400, detail=f"Unknown algorithm: {body.algorithm}. Available: {sorted(ASYNC_ALGORITHMS)}")
    job = await job_manager.create_job(job_type=body.algorithm, request=body.request)
    job_manager.run_job(job.id, run_algorithm(job.id, body.algorithm, body.request or {}))
    return job.to_dict()


@router.get("/jobs")
async def list_jobs() -> list[dict[str, Any]]:
    """List all jobs currently held in the in-memory store.

    Returns:
        list[dict]: A list of job records ordered by insertion.
    """
    return job_manager.get_all_jobs()


@router.get("/jobs/{job_id}")
async def get_job(job_id: str) -> dict[str, Any]:
    """Retrieve a single job by its UUID.

    Args:
        job_id: The unique identifier of the job.

    Returns:
        dict: The job record.

    Raises:
        HTTPException: 404 if the job does not exist.
    """
    job = job_manager.get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail=f"Job {job_id} not found")
    return job.to_dict()


@router.post("/jobs/{job_id}/cancel")
async def cancel_job(job_id: str) -> dict[str, Any]:
    """Cancel a running job.

    Requests cancellation of the asyncio Task backing the job.
    The algorithm coroutine will receive a ``CancelledError`` and the
    job status transitions to ``cancelled``.

    Raises:
        HTTPException: 404 if the job does not exist.
        HTTPException: 400 if the job is not cancellable (already finished).
    """
    job = job_manager.get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail=f"Job {job_id} not found")
    if job.status not in (JobStatus.CREATED, JobStatus.RUNNING):
        raise HTTPException(status_code=400, detail=f"Job {job_id} is already {job.status.value}")
    cancelled = job_manager.cancel_job(job_id)
    if cancelled:
        await job_manager.update_status(job_id, JobStatus.CANCELLED)
    return job.to_dict()


@router.get("/algorithms")
async def list_algorithms() -> list[dict[str, Any]]:
    """Return the catalogue of algorithms that can be submitted as jobs.

    Returns:
        list[dict]: Each entry contains ``id``, ``name``, and ``description``.
    """
    return [
        {"id": "shortest_path", "name": "Shortest Path", "description": "Find the shortest path between nodes", "mode": "async", "metadata": '{"icon": "route", "coloy": "pathfinding", "parameters": [{"name": "source", "type": "node", "required": true}, {"name": "target", "type": "node", "required": true}]}'},
        {"id": "community_detection", "name": "Community Detection", "description": "Detect communities in the graph", "mode": "async", "metadata": '{"icon": "groups", "color": "#ab47bc", "category": "clustering", "parameters": []}'},
        {"id": "pagerank", "name": "PageRank", "description": "Rank nodes by importance", "mode": "async", "metadata": '{"icon": "leaderboard", "color": "#ff7043", "category": "centrality", "parameters": [{"name": "damping", "type": "number", "required": false}]}'},
        {"id": "node_count", "name": "Node Count", "description": "Count nodes by type", "mode": "sync", "metadata": '{"icon": "tag", "color": "#66bb6a", "category": "statistics", "parameters": []}'},
        {"id": "degree_summary", "name": "Degree Summary", "description": "Basic degree statistics", "mode": "sync", "metadata": '{"icon": "analytics", "color": "#42a5f5", "category": "statistics", "parameters": []}'},
        {"id": "density", "name": "Density", "description": "Graph density calculation", "mode": "sync", "metadata": '{"icon": "blur_on", "color": "#ffa726", "category": "statistics", "parameters": []}'},
    ]


@router.post("/run")
async def run_sync(body: SyncRunRequest) -> dict[str, Any]:
    """Execute a fast synchronous algorithm and return the result directly.

    No job is created; the result is returned in the response body.
    Use this for lightweight algorithms that complete in milliseconds.
    """
    if body.algorithm not in SYNC_ALGORITHMS:
        raise HTTPException(status_code=400, detail=f"Unknown sync algorithm: {body.algorithm}")
    return run_sync_algorithm(body.algorithm, body.request or {})


@router.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket) -> None:
    """WebSocket endpoint for real-time job status updates.

    Once connected the server pushes a JSON message every time a job's
    status changes.  The client should send periodic ``ping`` text frames
    to keep the connection alive; no other client→server messages are
    required.
    """
    await websocket.accept()

    async def on_job_update(job: Job):
        try:
            status = job.status.value if hasattr(job.status, "value") else job.status
            messages = {
                "created": f"Job {job.id} has been created",
                "running": f"Job {job.id} is now running",
                "completed": f"Job {job.id} completed successfully",
                "failed": f"Job {job.id} failed: {job.error or 'unknown error'}",
                "cancelled": f"Job {job.id} was cancelled",
            }
            await websocket.send_json({
                "type": "analysis",
                "payload": job.to_dict(),
                "message": messages.get(status, f"Job {job.id} status: {status}"),
            })
            logger.info("Sent WS update for job %s [%s]", job.id, status)
        except Exception as exc:
            logger.exception("Failed to send WS update for job %s: %s", job.id, exc)

    job_manager.add_listener(on_job_update)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        job_manager.remove_listener(on_job_update)
