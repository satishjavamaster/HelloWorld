import pytest
import pytest_asyncio
from app.services.job_manager import Job, JobManager, JobStatus


class TestJob:
    def test_job_defaults(self):
        job = Job(job_type="shortest_path")
        assert job.job_type == "shortest_path"
        assert job.request == {}
        assert job.status == JobStatus.CREATED
        assert job.result is None
        assert job.error is None
        assert job.id  # UUID was generated

    def test_job_with_request(self):
        req = {"source": "A", "target": "B"}
        job = Job(job_type="pagerank", request=req)
        assert job.request == req

    def test_to_dict_keys(self):
        job = Job(job_type="density")
        d = job.to_dict()
        assert set(d.keys()) == {
            "id", "job_type", "request", "status",
            "result", "error", "created_at", "updated_at",
        }
        assert d["status"] == "created"
        assert d["request"] == {}


class TestJobManager:
    @pytest_asyncio.fixture(autouse=True)
    async def manager(self):
        self.mgr = JobManager()

    @pytest.mark.asyncio
    async def test_create_job(self):
        job = await self.mgr.create_job(job_type="shortest_path")
        assert job.status == JobStatus.CREATED
        assert self.mgr.get_job(job.id) is job

    @pytest.mark.asyncio
    async def test_create_job_with_request(self):
        req = {"damping": 0.85}
        job = await self.mgr.create_job(job_type="pagerank", request=req)
        assert job.request == req

    @pytest.mark.asyncio
    async def test_get_all_jobs(self):
        await self.mgr.create_job(job_type="shortest_path")
        await self.mgr.create_job(job_type="pagerank")
        jobs = self.mgr.get_all_jobs()
        assert len(jobs) == 2
        assert all(isinstance(j, dict) for j in jobs)

    @pytest.mark.asyncio
    async def test_get_job_missing(self):
        assert self.mgr.get_job("nonexistent") is None

    @pytest.mark.asyncio
    async def test_update_status_running(self):
        job = await self.mgr.create_job(job_type="shortest_path")
        await self.mgr.update_status(job.id, JobStatus.RUNNING)
        assert job.status == JobStatus.RUNNING

    @pytest.mark.asyncio
    async def test_update_status_completed_with_result(self):
        job = await self.mgr.create_job(job_type="shortest_path")
        result = {"path": ["A", "B"]}
        await self.mgr.update_status(job.id, JobStatus.COMPLETED, result=result)
        assert job.status == JobStatus.COMPLETED
        assert job.result == result

    @pytest.mark.asyncio
    async def test_update_status_failed_with_error(self):
        job = await self.mgr.create_job(job_type="shortest_path")
        await self.mgr.update_status(job.id, JobStatus.FAILED, error="boom")
        assert job.status == JobStatus.FAILED
        assert job.error == "boom"

    @pytest.mark.asyncio
    async def test_update_status_missing_job(self):
        # Should not raise
        await self.mgr.update_status("missing-id", JobStatus.RUNNING)

    @pytest.mark.asyncio
    async def test_updated_at_changes(self):
        job = await self.mgr.create_job(job_type="shortest_path")
        original = job.updated_at
        await self.mgr.update_status(job.id, JobStatus.RUNNING)
        assert job.updated_at >= original

    @pytest.mark.asyncio
    async def test_listener_notified(self):
        received = []

        async def listener(job: Job):
            received.append(job.to_dict())

        self.mgr.add_listener(listener)
        job = await self.mgr.create_job(job_type="shortest_path")
        await self.mgr.update_status(job.id, JobStatus.RUNNING)
        assert len(received) == 1
        assert received[0]["status"] == "running"

    @pytest.mark.asyncio
    async def test_remove_listener(self):
        received = []

        async def listener(job: Job):
            received.append(job)

        self.mgr.add_listener(listener)
        self.mgr.remove_listener(listener)
        job = await self.mgr.create_job(job_type="shortest_path")
        await self.mgr.update_status(job.id, JobStatus.RUNNING)
        assert len(received) == 0

    @pytest.mark.asyncio
    async def test_listener_exception_does_not_break(self):
        async def bad_listener(job: Job):
            raise RuntimeError("fail")

        received = []

        async def good_listener(job: Job):
            received.append(job)

        self.mgr.add_listener(bad_listener)
        self.mgr.add_listener(good_listener)
        job = await self.mgr.create_job(job_type="shortest_path")
        await self.mgr.update_status(job.id, JobStatus.RUNNING)
        assert len(received) == 1
