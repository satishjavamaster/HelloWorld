import json
import pytest
import pytest_asyncio
from unittest.mock import patch, AsyncMock
from fastapi import FastAPI
from httpx import AsyncClient, ASGITransport
from app.routers.planner import router
from app.services.job_manager import JobManager, JobStatus

# Standalone app with just the planner router (avoids neo4j import from other routers)
_app = FastAPI()
_app.include_router(router, prefix="/api/planner")


@pytest.fixture(autouse=True)
def fresh_job_manager():
    """Replace the global job_manager with a fresh instance for each test."""
    mgr = JobManager()
    with patch("app.routers.planner.job_manager", mgr), \
         patch("app.services.algorithms.job_manager", mgr):
        yield mgr


@pytest_asyncio.fixture
async def client(fresh_job_manager):
    transport = ASGITransport(app=_app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac


class TestListAlgorithms:
    @pytest.mark.asyncio
    async def test_returns_six_algorithms(self, client):
        resp = await client.get("/api/planner/algorithms")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 6

    @pytest.mark.asyncio
    async def test_algorithm_has_required_fields(self, client):
        resp = await client.get("/api/planner/algorithms")
        for algo in resp.json():
            assert "id" in algo
            assert "name" in algo
            assert "description" in algo
            assert "mode" in algo
            assert "metadata" in algo
            # metadata should be valid JSON string
            parsed = json.loads(algo["metadata"])
            assert "icon" in parsed

    @pytest.mark.asyncio
    async def test_algorithm_modes(self, client):
        resp = await client.get("/api/planner/algorithms")
        modes = {a["id"]: a["mode"] for a in resp.json()}
        assert modes["shortest_path"] == "async"
        assert modes["community_detection"] == "async"
        assert modes["pagerank"] == "async"
        assert modes["node_count"] == "sync"
        assert modes["degree_summary"] == "sync"
        assert modes["density"] == "sync"


class TestCreateJob:
    @pytest.mark.asyncio
    @patch("app.routers.planner.run_algorithm", new_callable=AsyncMock)
    async def test_create_job_success(self, mock_run, client):
        resp = await client.post(
            "/api/planner/jobs",
            json={"algorithm": "shortest_path", "request": {"source": "A"}},
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["job_type"] == "shortest_path"
        assert data["status"] == "created"
        assert data["request"] == {"source": "A"}

    @pytest.mark.asyncio
    async def test_create_job_unknown_algorithm(self, client):
        resp = await client.post(
            "/api/planner/jobs",
            json={"algorithm": "bogus"},
        )
        assert resp.status_code == 400
        assert "Unknown algorithm" in resp.json()["detail"]

    @pytest.mark.asyncio
    @patch("app.routers.planner.run_algorithm", new_callable=AsyncMock)
    async def test_create_job_default_request(self, mock_run, client):
        resp = await client.post(
            "/api/planner/jobs",
            json={"algorithm": "pagerank"},
        )
        assert resp.status_code == 201
        assert resp.json()["request"] == {}


class TestListJobs:
    @pytest.mark.asyncio
    async def test_empty(self, client):
        resp = await client.get("/api/planner/jobs")
        assert resp.status_code == 200
        assert resp.json() == []

    @pytest.mark.asyncio
    @patch("app.routers.planner.run_algorithm", new_callable=AsyncMock)
    async def test_after_create(self, mock_run, client):
        await client.post("/api/planner/jobs", json={"algorithm": "shortest_path"})
        resp = await client.get("/api/planner/jobs")
        assert len(resp.json()) == 1


class TestGetJob:
    @pytest.mark.asyncio
    @patch("app.routers.planner.run_algorithm", new_callable=AsyncMock)
    async def test_get_existing_job(self, mock_run, client):
        create_resp = await client.post(
            "/api/planner/jobs", json={"algorithm": "shortest_path"}
        )
        job_id = create_resp.json()["id"]
        resp = await client.get(f"/api/planner/jobs/{job_id}")
        assert resp.status_code == 200
        assert resp.json()["id"] == job_id

    @pytest.mark.asyncio
    async def test_get_missing_job(self, client):
        resp = await client.get("/api/planner/jobs/nonexistent-id")
        assert resp.status_code == 404


class TestRunSync:
    @pytest.mark.asyncio
    async def test_node_count(self, client):
        resp = await client.post(
            "/api/planner/run",
            json={"algorithm": "node_count"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["algorithm"] == "node_count"
        assert "employees" in data

    @pytest.mark.asyncio
    async def test_degree_summary(self, client):
        resp = await client.post(
            "/api/planner/run",
            json={"algorithm": "degree_summary"},
        )
        assert resp.status_code == 200
        assert resp.json()["algorithm"] == "degree_summary"

    @pytest.mark.asyncio
    async def test_density(self, client):
        resp = await client.post(
            "/api/planner/run",
            json={"algorithm": "density"},
        )
        assert resp.status_code == 200
        assert resp.json()["algorithm"] == "density"

    @pytest.mark.asyncio
    async def test_unknown_sync_algorithm(self, client):
        resp = await client.post(
            "/api/planner/run",
            json={"algorithm": "bogus"},
        )
        assert resp.status_code == 400
        assert "Unknown sync algorithm" in resp.json()["detail"]

    @pytest.mark.asyncio
    async def test_sync_does_not_create_job(self, client):
        await client.post("/api/planner/run", json={"algorithm": "node_count"})
        jobs_resp = await client.get("/api/planner/jobs")
        assert jobs_resp.json() == []
