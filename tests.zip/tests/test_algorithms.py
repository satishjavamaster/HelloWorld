import pytest
from unittest.mock import patch, AsyncMock
from app.services.algorithms import (
    run_sync_algorithm,
    ASYNC_ALGORITHMS,
    SYNC_ALGORITHMS,
)
from app.services.job_manager import JobStatus


class TestAlgorithmConstants:
    def test_async_algorithms(self):
        assert ASYNC_ALGORITHMS == {"shortest_path", "community_detection", "pagerank"}

    def test_sync_algorithms(self):
        assert SYNC_ALGORITHMS == {"node_count", "degree_summary", "density"}

    def test_no_overlap(self):
        assert ASYNC_ALGORITHMS.isdisjoint(SYNC_ALGORITHMS)


class TestRunSyncAlgorithm:
    def test_node_count_returns_expected_keys(self):
        result = run_sync_algorithm("node_count", {})
        assert result["algorithm"] == "node_count"
        assert "employees" in result
        assert "organizations" in result

    def test_degree_summary_returns_expected_keys(self):
        result = run_sync_algorithm("degree_summary", {})
        assert result["algorithm"] == "degree_summary"
        assert "min_degree" in result
        assert "max_degree" in result
        assert "avg_degree" in result

    def test_density_returns_expected_keys(self):
        result = run_sync_algorithm("density", {})
        assert result["algorithm"] == "density"
        assert "density" in result
        assert "total_nodes" in result
        assert "total_edges" in result

    def test_unknown_algorithm_raises(self):
        with pytest.raises(ValueError, match="Unknown sync algorithm"):
            run_sync_algorithm("bogus", {})


class TestRunAlgorithm:
    @pytest.mark.asyncio
    @patch("app.services.algorithms.asyncio.sleep", new_callable=AsyncMock)
    async def test_shortest_path_completes(self, mock_sleep):
        from app.services.algorithms import run_algorithm
        from app.services.job_manager import JobManager

        mgr = JobManager()
        with patch("app.services.algorithms.job_manager", mgr):
            job = await mgr.create_job(job_type="shortest_path")
            await run_algorithm(job.id, "shortest_path", {"source": "X", "target": "Y"})
            assert job.status == JobStatus.COMPLETED
            assert job.result["source"] == "X"
            assert job.result["target"] == "Y"

    @pytest.mark.asyncio
    @patch("app.services.algorithms.asyncio.sleep", new_callable=AsyncMock)
    async def test_community_detection_completes(self, mock_sleep):
        from app.services.algorithms import run_algorithm
        from app.services.job_manager import JobManager

        mgr = JobManager()
        with patch("app.services.algorithms.job_manager", mgr):
            job = await mgr.create_job(job_type="community_detection")
            await run_algorithm(job.id, "community_detection", {})
            assert job.status == JobStatus.COMPLETED
            assert "communities_found" in job.result

    @pytest.mark.asyncio
    @patch("app.services.algorithms.asyncio.sleep", new_callable=AsyncMock)
    async def test_pagerank_completes(self, mock_sleep):
        from app.services.algorithms import run_algorithm
        from app.services.job_manager import JobManager

        mgr = JobManager()
        with patch("app.services.algorithms.job_manager", mgr):
            job = await mgr.create_job(job_type="pagerank")
            await run_algorithm(job.id, "pagerank", {})
            assert job.status == JobStatus.COMPLETED
            assert "top_nodes" in job.result

    @pytest.mark.asyncio
    @patch("app.services.algorithms.asyncio.sleep", new_callable=AsyncMock)
    async def test_unknown_algorithm_fails_job(self, mock_sleep):
        from app.services.algorithms import run_algorithm
        from app.services.job_manager import JobManager

        mgr = JobManager()
        with patch("app.services.algorithms.job_manager", mgr):
            job = await mgr.create_job(job_type="bogus")
            await run_algorithm(job.id, "bogus", {})
            assert job.status == JobStatus.FAILED
            assert "Unknown algorithm" in job.error

    @pytest.mark.asyncio
    @patch("app.services.algorithms.asyncio.sleep", new_callable=AsyncMock)
    async def test_run_algorithm_transitions_through_running(self, mock_sleep):
        from app.services.algorithms import run_algorithm
        from app.services.job_manager import JobManager

        statuses = []
        mgr = JobManager()

        async def track(job):
            statuses.append(job.status.value)

        mgr.add_listener(track)
        with patch("app.services.algorithms.job_manager", mgr):
            job = await mgr.create_job(job_type="shortest_path")
            await run_algorithm(job.id, "shortest_path", {})
            assert "running" in statuses
            assert "completed" in statuses
