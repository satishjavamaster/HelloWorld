import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PlannerService, Job, AlgorithmInfo } from '../../services/planner.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-planner',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './planner.component.html',
  styleUrls: ['./planner.component.scss']
})
export class PlannerComponent implements OnInit, OnDestroy {
  algorithms: AlgorithmInfo[] = [];
  jobs: Job[] = [];
  syncResults: { algorithm: string; result: any; timestamp: string }[] = [];
  selectedAlgorithm = '';
  private wsSub: Subscription | null = null;

  constructor(private plannerService: PlannerService) {}

  ngOnInit(): void {
    this.loadAlgorithms();
    this.loadJobs();
    this.subscribeToUpdates();
  }

  ngOnDestroy(): void {
    this.wsSub?.unsubscribe();
    this.plannerService.disconnectWebSocket();
  }

  loadAlgorithms(): void {
    this.plannerService.getAlgorithms().subscribe(
      (data) => this.algorithms = data,
      (err) => console.error('Error loading algorithms:', err)
    );
  }

  loadJobs(): void {
    this.plannerService.getJobs().subscribe(
      (data) => this.jobs = data,
      (err) => console.error('Error loading jobs:', err)
    );
  }

  subscribeToUpdates(): void {
    this.wsSub = this.plannerService.connectWebSocket().subscribe((updatedJob) => {
      const idx = this.jobs.findIndex((j) => j.id === updatedJob.id);
      if (idx >= 0) {
        this.jobs = this.jobs.map((j, i) => i === idx ? updatedJob : j);
      } else {
        this.jobs = [...this.jobs, updatedJob];
      }
    });
  }

  get selectedMode(): string {
    return this.algorithms.find(a => a.id === this.selectedAlgorithm)?.mode || '';
  }

  runJob(): void {
    if (!this.selectedAlgorithm) return;

    if (this.selectedMode === 'sync') {
      this.plannerService.runSync(this.selectedAlgorithm).subscribe(
        (result) => {
          this.syncResults.unshift({
            algorithm: this.selectedAlgorithm,
            result,
            timestamp: new Date().toISOString()
          });
        },
        (err) => console.error('Error running sync algorithm:', err)
      );
    } else {
      this.plannerService.createJob(this.selectedAlgorithm).subscribe(
        (job) => {
          if (!this.jobs.some((j) => j.id === job.id)) {
            this.jobs.unshift(job);
          }
        },
        (err) => console.error('Error creating job:', err)
      );
    }
  }

  statusClass(status: string): string {
    switch (status) {
      case 'created': return 'badge-created';
      case 'running': return 'badge-running';
      case 'completed': return 'badge-completed';
      case 'failed': return 'badge-failed';
      default: return '';
    }
  }
}
