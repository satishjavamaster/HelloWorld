# Planner – Sync & Async Algorithm Execution

The Planner subsystem lets the frontend run graph algorithms in two modes:

- **Sync** – fast algorithms that return results directly in the HTTP response.
- **Async** – long-running algorithms executed as background jobs with real-time WebSocket status updates.

## Architecture

```
┌──────────┐  POST /run    ┌──────────────┐  direct return        ┌─────────────┐
│  Angular  │ ────────────► │ planner.py   │ ───────────────────► │algorithms.py │
│  Client   │◄──── 200 ─── │  (router)    │◄──────────────────── │ (sync fns)   │
│           │               │              │                      │              │
│           │  POST /jobs   │              │  asyncio.create_task  │              │
│           │ ────────────► │              │ ───────────────────► │ (async fns)  │
│           │◄──── WS ──── │              │◄── update_status ─── │              │
└──────────┘               └──────┬───────┘                      └──────────────┘
                                  │
                           ┌──────▼───────┐
                           │job_manager.py │  (in-memory store
                           │  JobManager   │   + listener hub)
                           └──────────────┘
```

## Files

| File | Purpose |
|------|---------|
| `app/routers/planner.py` | FastAPI router – REST endpoints + WebSocket |
| `app/services/job_manager.py` | In-memory job store with pub-sub listeners |
| `app/services/algorithms.py` | Algorithm implementations (sync + async, simulated) |

## API Endpoints

All endpoints are prefixed with `/api/planner`.

### `GET /algorithms`

Returns the list of available algorithms. Each entry includes a `mode` field (`"sync"` or `"async"`).

```json
[
  { "id": "shortest_path",       "name": "Shortest Path",       "description": "...", "mode": "async" },
  { "id": "community_detection", "name": "Community Detection", "description": "...", "mode": "async" },
  { "id": "pagerank",            "name": "PageRank",            "description": "...", "mode": "async" },
  { "id": "node_count",          "name": "Node Count",          "description": "...", "mode": "sync" },
  { "id": "degree_summary",      "name": "Degree Summary",      "description": "...", "mode": "sync" },
  { "id": "density",             "name": "Density",             "description": "...", "mode": "sync" }
]
```

### `POST /run`

Execute a synchronous algorithm and get the result immediately (no job created).

**Request body:**

```json
{
  "algorithm": "node_count",
  "parameters": {}
}
```

**Response (200):** the algorithm result directly.

**Error (400):** unknown algorithm → `{ "detail": "Unknown sync algorithm: ..." }`

### `POST /jobs`

Create and launch an async job. The algorithm is validated against `ASYNC_ALGORITHMS` before the job is created.

**Request body:**

```json
{
  "algorithm": "shortest_path",
  "parameters": {}
}
```

**Response (201 Created):** the created job object (status = `created`).

**Error (400):** unknown algorithm → `{ "detail": "Unknown algorithm: ... Available: [...]" }`

### `GET /jobs`

List all jobs in the in-memory store.

### `GET /jobs/{job_id}`

Get a single job by UUID.

**Response (200):** the job object.

**Error (404):** job not found → `{ "detail": "Job <id> not found" }`

### `WS /ws`

WebSocket endpoint. After connecting, the server pushes a JSON message on every job status change:

```json
{
  "id": "...",
  "job_type": "shortest_path",
  "status": "running",
  "result": null,
  "error": null,
  "created_at": "...",
  "updated_at": "..."
}
```

The client should send periodic `ping` text frames to keep the connection alive.

## Job Lifecycle

```
created  ──►  running  ──►  completed
                  │
                  └────►  failed
```

Status transitions are broadcast to all connected WebSocket clients via the `JobManager` listener pattern.

**Race-condition prevention:** The background task yields to the event loop (`await asyncio.sleep(0)`) before transitioning from `created` → `running`, ensuring the HTTP response is delivered first. The `created` status is delivered via the HTTP response only (no WebSocket notification), while subsequent transitions (`running`, `completed`, `failed`) are broadcast over WebSocket.

## Algorithms (stubs)

### Async (long-running, job-based)

| Algorithm | Simulated Duration | Output |
|-----------|--------------------|--------|
| `shortest_path` | ~5 s | source, target, path, cost, nodes explored |
| `community_detection` | ~8 s | cluster count and sizes |
| `pagerank` | ~6 s | top-5 nodes with scores |

### Sync (fast, direct return)

| Algorithm | Output |
|-----------|--------|
| `node_count` | employee and organization counts |
| `degree_summary` | min, max, avg degree |
| `density` | graph density, total nodes/edges |

All are placeholders – replace the `_algo_*` / `_sync_*` functions in `algorithms.py` with real implementations.

## Key Design Decisions

- **Two execution modes** – sync algorithms use `POST /run` for instant results; async algorithms use `POST /jobs` + WebSocket for progress tracking.
- **In-memory only** – jobs are stored in a Python dict; no database or message broker required. Jobs are lost on restart.
- **`asyncio.create_task`** – algorithms run as fire-and-forget coroutines in the same event loop (no thread pool, no Celery).
- **Listener pattern** – `JobManager` holds a list of async callbacks. The WebSocket handler registers itself as a listener on connect and deregisters on disconnect.
- **No duplicate notifications on creation** – `create_job` does *not* notify listeners; the HTTP response delivers the initial `created` state. This avoids duplicate entries when both the HTTP response and a WebSocket message arrive.
- **NgZone-aware WebSocket** – the Angular `PlannerService` wraps WebSocket emissions in `NgZone.run()` and the component uses immutable array updates to guarantee change detection fires on every status transition.
