"""In-memory job manager for the Planner subsystem.

Provides :class:`JobManager` – a lightweight, in-process store that tracks
algorithm jobs and notifies registered async listeners on every status
change.  This is intentionally simple (no persistence, no external broker)
so that the planner can run without extra infrastructure.

Key classes
-----------
- :class:`JobStatus` – enum of valid statuses (created / running / completed / failed).
- :class:`Job`       – data object representing a single algorithm execution.
- :class:`JobManager` – singleton store + pub-sub notification hub.
"""

import uuid
import asyncio
from datetime import datetime
from typing import Dict, List, Optional, Callable, Awaitable
from enum import Enum


class JobStatus(str, Enum):
    CREATED = "created"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class Job:
    """Represents a single algorithm job.

    Attributes:
        id: Auto-generated UUID.
        job_type: Algorithm identifier (e.g. ``shortest_path``).
        parameters: Algorithm-specific input parameters.
        status: Current lifecycle state (:class:`JobStatus`).
        result: Output payload set on successful completion.
        error: Error message set on failure.
        created_at: ISO-8601 creation timestamp.
        updated_at: ISO-8601 last-update timestamp.
    """

    def __init__(self, job_type: str, parameters: Dict = None):
        self.id = str(uuid.uuid4())
        self.job_type = job_type
        self.parameters = parameters or {}
        self.status = JobStatus.CREATED
        self.result = None
        self.error = None
        self.created_at = datetime.utcnow().isoformat()
        self.updated_at = self.created_at

    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "job_type": self.job_type,
            "parameters": self.parameters,
            "status": self.status.value,
            "result": self.result,
            "error": self.error,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }


class JobManager:
    """In-memory job manager for tracking async algorithm jobs."""

    def __init__(self):
        self.jobs: Dict[str, Job] = {}
        self._listeners: List[Callable[[Job], Awaitable[None]]] = []

    async def create_job(self, job_type: str, parameters: Dict = None) -> Job:
        """Create a new job, store it, and return it (status = CREATED).

        Listeners are *not* notified here – the caller returns the job
        via the HTTP response.  Notifications begin with the first
        status transition (CREATED → RUNNING).
        """
        job = Job(job_type=job_type, parameters=parameters)
        self.jobs[job.id] = job
        return job

    async def update_status(self, job_id: str, status: JobStatus, result=None, error=None):
        """Transition a job to a new status and notify all listeners."""
        job = self.jobs.get(job_id)
        if not job:
            return
        job.status = status
        job.updated_at = datetime.utcnow().isoformat()
        if result is not None:
            job.result = result
        if error is not None:
            job.error = error
        await self._notify(job)

    def get_job(self, job_id: str) -> Optional[Job]:
        return self.jobs.get(job_id)

    def get_all_jobs(self) -> List[Dict]:
        return [j.to_dict() for j in self.jobs.values()]

    def add_listener(self, callback: Callable[[Job], Awaitable[None]]):
        self._listeners.append(callback)

    def remove_listener(self, callback: Callable[[Job], Awaitable[None]]):
        self._listeners = [l for l in self._listeners if l is not callback]

    async def _notify(self, job: Job):
        for listener in self._listeners:
            try:
                await listener(job)
            except Exception:
                pass


job_manager = JobManager()
