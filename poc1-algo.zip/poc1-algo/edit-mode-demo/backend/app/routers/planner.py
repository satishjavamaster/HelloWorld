"""Planner router – exposes REST and WebSocket endpoints for running
graph algorithms in sync and async modes.

Endpoints
---------
- ``POST /jobs``          – Create and launch a new async algorithm job
                            (returns 201, validates against ``ASYNC_ALGORITHMS``).
- ``GET  /jobs``          – List all jobs (in-memory store).
- ``GET  /jobs/{job_id}`` – Retrieve a single job by ID (404 if missing).
- ``GET  /algorithms``    – List the algorithms available for execution.
- ``POST /run``           – Execute a fast sync algorithm and return the
                            result directly (400 if unknown algorithm).
- ``WS   /ws``            – WebSocket stream that pushes real-time job
                            status updates (created → running → completed / failed).

Error handling
--------------
All error conditions raise :class:`~fastapi.HTTPException` with
appropriate status codes (400 for bad input, 404 for missing resources)
rather than returning 200 with an error payload.

Dependencies
------------
- :mod:`app.services.job_manager` – in-memory job store & listener system.
- :mod:`app.services.algorithms`  – algorithm implementations (sync & async).
"""

import asyncio
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, HTTPException
from pydantic import BaseModel
from typing import Optional, Dict
from app.services.job_manager import job_manager, Job
from app.services.algorithms import run_algorithm, run_sync_algorithm, ASYNC_ALGORITHMS, SYNC_ALGORITHMS

router = APIRouter()


class SyncRunRequest(BaseModel):
    """Request body for running a synchronous (fast) algorithm.

    Attributes:
        algorithm: Identifier of the sync algorithm
                   (e.g. ``node_count``, ``degree_summary``, ``density``).
        parameters: Optional dictionary of algorithm-specific parameters.
    """

    algorithm: str
    parameters: Optional[Dict] = None


class JobCreate(BaseModel):
    """Request body for creating a new algorithm job.

    Attributes:
        algorithm: Identifier of the algorithm to run
                   (e.g. ``shortest_path``, ``community_detection``, ``pagerank``).
        parameters: Optional dictionary of algorithm-specific parameters.
    """

    algorithm: str
    parameters: Optional[Dict] = None


@router.post("/jobs", status_code=201)
async def create_job(body: JobCreate):
    """Create and launch a new algorithm job.

    The job is persisted in the in-memory :class:`JobManager` and the
    algorithm is executed as a fire-and-forget ``asyncio.Task``.  Status
    transitions (created → running → completed/failed) are broadcast to
    all connected WebSocket clients.

    Returns:
        dict: The newly created job record.

    Raises:
        HTTPException: 400 if the algorithm is not recognised.
    """
    if body.algorithm not in ASYNC_ALGORITHMS:
        raise HTTPException(status_code=400, detail=f"Unknown algorithm: {body.algorithm}. Available: {sorted(ASYNC_ALGORITHMS)}")
    job = await job_manager.create_job(job_type=body.algorithm, parameters=body.parameters)
    # Fire-and-forget: run algorithm in background
    asyncio.create_task(run_algorithm(job.id, body.algorithm, body.parameters or {}))
    return job.to_dict()


@router.get("/jobs")
async def list_jobs():
    """List all jobs currently held in the in-memory store.

    Returns:
        list[dict]: A list of job records ordered by insertion.
    """
    return job_manager.get_all_jobs()


@router.get("/jobs/{job_id}")
async def get_job(job_id: str):
    """Retrieve a single job by its UUID.

    Args:
        job_id: The unique identifier of the job.

    Returns:
        dict: The job record.

    Raises:
        HTTPException: 404 if the job does not exist.
    """
    job = job_manager.get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail=f"Job {job_id} not found")
    return job.to_dict()


@router.get("/algorithms")
async def list_algorithms():
    """Return the catalogue of algorithms that can be submitted as jobs.

    Returns:
        list[dict]: Each entry contains ``id``, ``name``, and ``description``.
    """
    return [
        {"id": "shortest_path", "name": "Shortest Path", "description": "Find the shortest path between nodes", "mode": "async"},
        {"id": "community_detection", "name": "Community Detection", "description": "Detect communities in the graph", "mode": "async"},
        {"id": "pagerank", "name": "PageRank", "description": "Rank nodes by importance", "mode": "async"},
        {"id": "node_count", "name": "Node Count", "description": "Count nodes by type", "mode": "sync"},
        {"id": "degree_summary", "name": "Degree Summary", "description": "Basic degree statistics", "mode": "sync"},
        {"id": "density", "name": "Density", "description": "Graph density calculation", "mode": "sync"},
    ]


@router.post("/run")
async def run_sync(body: SyncRunRequest):
    """Execute a fast synchronous algorithm and return the result directly.

    No job is created; the result is returned in the response body.
    Use this for lightweight algorithms that complete in milliseconds.
    """
    if body.algorithm not in SYNC_ALGORITHMS:
        raise HTTPException(status_code=400, detail=f"Unknown sync algorithm: {body.algorithm}")
    return run_sync_algorithm(body.algorithm, body.parameters or {})


@router.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket endpoint for real-time job status updates.

    Once connected the server pushes a JSON message every time a job's
    status changes.  The client should send periodic ``ping`` text frames
    to keep the connection alive; no other client→server messages are
    required.
    """
    await websocket.accept()

    async def on_job_update(job: Job):
        try:
            await websocket.send_json(job.to_dict())
        except Exception:
            pass

    job_manager.add_listener(on_job_update)
    try:
        while True:
            # Keep connection alive; client can send pings
            await websocket.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        job_manager.remove_listener(on_job_update)
