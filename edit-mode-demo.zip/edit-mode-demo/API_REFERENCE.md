# API Reference

## Base URL
```
http://localhost:8000/api
```

## Authentication
The current implementation does not require authentication. For production, implement JWT-based auth.

## Common Response Format

### Success Response (2xx)
```json
{
  "data": {},
  "message": "Operation successful"
}
```

### Error Response (4xx, 5xx)
```json
{
  "detail": "Error message describing what went wrong"
}
```

---

## Employees Endpoints

### Create Employee
```http
POST /employees/
Content-Type: application/json

{
  "name": "John Doe",
  "email": "john@example.com",
  "title": "Software Engineer",
  "department": "Engineering"
}
```

**Response**: 201 Created
```json
{
  "id": "uuid-string",
  "name": "John Doe",
  "email": "john@example.com",
  "title": "Software Engineer",
  "department": "Engineering",
  "created_at": "2024-03-02T10:30:00Z",
  "updated_at": "2024-03-02T10:30:00Z"
}
```

### Get All Employees
```http
GET /employees/
```

**Response**: 200 OK
```json
[
  {
    "id": "uuid-1",
    "name": "John Doe",
    "email": "john@example.com",
    "title": "Software Engineer",
    "department": "Engineering",
    "created_at": "2024-03-02T10:30:00Z",
    "updated_at": "2024-03-02T10:30:00Z"
  },
  {
    "id": "uuid-2",
    "name": "Jane Smith",
    "email": "jane@example.com",
    "title": "Product Manager",
    "department": "Product",
    "created_at": "2024-03-02T11:00:00Z",
    "updated_at": "2024-03-02T11:00:00Z"
  }
]
```

### Get Employee Details
```http
GET /employees/{employee_id}
```

**Parameters**:
- `employee_id` (path, required): UUID of the employee

**Response**: 200 OK
```json
{
  "id": "uuid-string",
  "name": "John Doe",
  "email": "john@example.com",
  "title": "Software Engineer",
  "department": "Engineering",
  "created_at": "2024-03-02T10:30:00Z",
  "updated_at": "2024-03-02T10:30:00Z"
}
```

### Update Employee
```http
PUT /employees/{employee_id}
Content-Type: application/json

{
  "name": "John Doe Updated",
  "title": "Senior Software Engineer"
}
```

**Parameters**:
- `employee_id` (path, required): UUID of the employee

Note: Send only the fields you want to update.

**Response**: 200 OK
```json
{
  "id": "uuid-string",
  "name": "John Doe Updated",
  "email": "john@example.com",
  "title": "Senior Software Engineer",
  "department": "Engineering",
  "created_at": "2024-03-02T10:30:00Z",
  "updated_at": "2024-03-02T10:35:00Z"
}
```

### Delete Employee
```http
DELETE /employees/{employee_id}
```

**Parameters**:
- `employee_id` (path, required): UUID of the employee

**Response**: 200 OK
```json
{
  "message": "Employee deleted successfully"
}
```

---

## Organizations Endpoints

### Create Organization
```http
POST /organizations/
Content-Type: application/json

{
  "name": "Acme Corp",
  "description": "Technology company",
  "location": "San Francisco, CA"
}
```

**Response**: 201 Created
```json
{
  "id": "uuid-string",
  "name": "Acme Corp",
  "description": "Technology company",
  "location": "San Francisco, CA",
  "created_at": "2024-03-02T10:30:00Z",
  "updated_at": "2024-03-02T10:30:00Z"
}
```

### Get All Organizations
```http
GET /organizations/
```

**Response**: 200 OK
```json
[
  {
    "id": "uuid-1",
    "name": "Acme Corp",
    "description": "Technology company",
    "location": "San Francisco, CA",
    "created_at": "2024-03-02T10:30:00Z",
    "updated_at": "2024-03-02T10:30:00Z"
  }
]
```

### Get Organization Details
```http
GET /organizations/{org_id}
```

**Response**: 200 OK

### Update Organization
```http
PUT /organizations/{org_id}
Content-Type: application/json

{
  "description": "Technology company specializing in AI",
  "location": "San Francisco, CA"
}
```

**Response**: 200 OK

### Delete Organization
```http
DELETE /organizations/{org_id}
```

**Response**: 200 OK

---

## Relationships Endpoints

### Create Relationship
```http
POST /relationships/
Content-Type: application/json

{
  "employee_id": "employee-uuid",
  "organization_id": "org-uuid",
  "role": "Senior Engineer"
}
```

**Parameters**:
- `employee_id` (body, required): UUID of the employee
- `organization_id` (body, required): UUID of the organization
- `role` (body, optional): Role in the organization, default: "member"

**Response**: 201 Created
```json
{
  "id": "rel-uuid",
  "employee_id": "employee-uuid",
  "organization_id": "org-uuid",
  "role": "Senior Engineer"
}
```

### Get All Relationships
```http
GET /relationships/
```

**Response**: 200 OK
```json
[
  {
    "id": "rel-uuid",
    "employee_id": "employee-uuid",
    "employee_name": "John Doe",
    "organization_id": "org-uuid",
    "organization_name": "Acme Corp",
    "role": "Senior Engineer",
    "created_at": "2024-03-02T10:30:00Z",
    "updated_at": "2024-03-02T10:30:00Z"
  }
]
```

### Update Relationship
```http
PUT /relationships/{rel_id}
Content-Type: application/json

{
  "role": "Lead Engineer"
}
```

**Response**: 200 OK
```json
{
  "message": "Relationship updated successfully"
}
```

### Delete Relationship
```http
DELETE /relationships/{rel_id}
```

**Response**: 200 OK

---

## History & Graph Endpoints

### Get Audit Events
```http
GET /history/events?limit=100
```

**Parameters**:
- `limit` (query, optional): Maximum number of events to return, default: 100

**Response**: 200 OK
```json
[
  {
    "id": "audit-uuid",
    "entity_type": "EMPLOYEE",
    "entity_id": "employee-uuid",
    "operation": "CREATE",
    "changes": {
      "name": "John Doe",
      "email": "john@example.com",
      "title": "Software Engineer"
    },
    "changed_by": "system",
    "timestamp": "2024-03-02T10:30:00Z",
    "version": 0
  },
  {
    "id": "audit-uuid-2",
    "entity_type": "EMPLOYEE",
    "entity_id": "employee-uuid",
    "operation": "UPDATE",
    "changes": {
      "title": "Senior Software Engineer"
    },
    "changed_by": "system",
    "timestamp": "2024-03-02T10:35:00Z",
    "version": 1
  }
]
```

### Get Entity History
```http
GET /history/entity/{entity_id}
```

**Parameters**:
- `entity_id` (path, required): UUID of the entity (employee/org/relationship)

**Response**: 200 OK
Returns list of AuditEvent objects for the specific entity.

### Get Full Graph
```http
GET /history/graph
```

**Response**: 200 OK
```json
{
  "nodes": [
    {
      "id": "employee-uuid",
      "label": "John Doe",
      "type": "employee",
      "properties": {
        "name": "John Doe",
        "email": "john@example.com",
        "title": "Software Engineer",
        "department": "Engineering"
      }
    },
    {
      "id": "org-uuid",
      "label": "Acme Corp",
      "type": "organization",
      "properties": {
        "name": "Acme Corp",
        "description": "Technology company",
        "location": "San Francisco, CA"
      }
    }
  ],
  "edges": [
    {
      "source": "employee-uuid",
      "target": "org-uuid",
      "label": "Senior Engineer"
    }
  ]
}
```

### Get Graph at Timestamp
```http
GET /history/graph/at/{timestamp}
```

**Parameters**:
- `timestamp` (path, required): ISO 8601 datetime string

**Response**: 200 OK
Returns graph state at the specified timestamp (foundation for replay feature).

---

## Error Codes

| Code | Description |
|------|-------------|
| 200 | Success |
| 201 | Created |
| 400 | Bad Request (validation error) |
| 404 | Not Found |
| 500 | Internal Server Error |

## Common Error Responses

### Not Found
```json
{
  "detail": "Employee not found"
}
```

### Validation Error
```json
{
  "detail": "No updates provided"
}
```

### Server Error
```json
{
  "detail": "Internal server error"
}
```

---

## Rate Limiting
Currently not implemented. For production deployment, add rate limiting middleware.

## CORS
Currently allows all origins (`*`). For production, restrict to specific domains:
```python
allow_origins=["https://yourdomain.com"]
```

## Testing with cURL

### Create Employee
```bash
curl -X POST http://localhost:8000/api/employees/ \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Alice Johnson",
    "email": "alice@example.com",
    "title": "Data Scientist",
    "department": "AI"
  }'
```

### Create Organization
```bash
curl -X POST http://localhost:8000/api/organizations/ \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Tech Startup Inc",
    "description": "AI-powered analytics",
    "location": "New York, NY"
  }'
```

### Create Relationship
```bash
curl -X POST http://localhost:8000/api/relationships/ \
  -H "Content-Type: application/json" \
  -d '{
    "employee_id": "EMPLOYEE-UUID",
    "organization_id": "ORG-UUID",
    "role": "Lead Data Scientist"
  }'
```

### Get Full Graph
```bash
curl http://localhost:8000/api/history/graph | jq
```

### Get Audit Events
```bash
curl "http://localhost:8000/api/history/events?limit=50" | jq
```

---

## Development Notes

- All timestamps are in UTC (ISO 8601 format)
- UUIDs are generated server-side
- Audit events are created automatically for all mutations
- Graph queries use Cypher pattern matching
- All CRUD operations are transactional
