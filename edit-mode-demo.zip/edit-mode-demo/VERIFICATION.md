# Verification Checklist

After running `docker-compose up --build`, use this checklist to verify everything works correctly.

## Pre-Startup Check

- [ ] Ports 4200, 7474, 7687, 8000 are available
- [ ] Docker and Docker Compose installed
- [ ] At least 4GB RAM available
- [ ] Docker daemon running

## Startup (First Run)

```bash
cd c:/Users/satis/work/edit-mode-demo
docker-compose up --build
```

This will:
- Build Docker images for backend and frontend
- Start Neo4j container (may take 20-30 seconds)
- Start FastAPI backend
- Start Angular dev server

Wait ~30-45 seconds for all services to be healthy.

- [ ] No errors in terminal
- [ ] All 3 containers running (`docker-compose ps` shows 3 running)
- [ ] Neo4j is healthy (check logs for "started")

## Service Verification

### 1. Neo4j Database

```bash
# Check Neo4j is accessible
curl http://localhost:7474
```

- [ ] HTTP 200 response
- [ ] Can access http://localhost:7474 in browser
- [ ] Login with neo4j / password123
- [ ] Browser shows empty database

### 2. FastAPI Backend

```bash
# Check backend health
curl http://localhost:8000/health
```

- [ ] Response: `{"status":"healthy"}`
- [ ] Access http://localhost:8000/docs (Swagger UI)
- [ ] All endpoints listed
- [ ] No Python errors in logs

```bash
docker-compose logs backend | grep -i error
```

- [ ] No ERROR lines

### 3. Angular Frontend

```bash
# Check frontend is serving
curl http://localhost:4200/index.html
```

- [ ] Can access http://localhost:4200 in browser
- [ ] Landing page loads without errors
- [ ] Navigation bar visible with 5 links
- [ ] No JavaScript errors in browser console

## Feature Testing

### Dashboard Page

Navigate to http://localhost:4200/

- [ ] Dashboard page loads
- [ ] 4 stat cards visible: Employees, Organizations, Relationships, Recent Changes
- [ ] All stats show 0 initially

### Create Employee

Go to Employees page (`/employees`):

- [ ] Click "+ Add Employee" button
- [ ] Form appears with fields: Name, Email, Title, Department
- [ ] Fill in form:
  ```
  Name: John Doe
  Email: john@example.com
  Title: Software Engineer
  Department: Engineering
  ```
- [ ] Click Save
- [ ] Form closes
- [ ] Employee appears in table
- [ ] Dashboard now shows 1 employee

**API Test:**
```bash
curl http://localhost:8000/api/employees/
```
- [ ] Returns array with 1 employee
- [ ] Employee has created_at and updated_at timestamps

### Create Organization

Go to Organizations page (`/organizations`):

- [ ] Click "+ Add Organization" button
- [ ] Form appears
- [ ] Fill in form:
  ```
  Name: Acme Corp
  Description: Technology Company
  Location: San Francisco, CA
  ```
- [ ] Click Save
- [ ] Organization appears in table
- [ ] Dashboard now shows 1 organization

**API Test:**
```bash
curl http://localhost:8000/api/organizations/
```
- [ ] Returns array with 1 organization

### Edit Employee

In Employees table:

- [ ] Click "Edit" button for John Doe
- [ ] Form appears with pre-filled data
- [ ] Change title to "Senior Software Engineer"
- [ ] Click Save
- [ ] Form closes
- [ ] Table shows updated title
- [ ] Dashboard still shows 1 employee

**API Test:**
```bash
curl http://localhost:8000/api/history/events
```
- [ ] First event: EMPLOYEE CREATE
- [ ] Second event: EMPLOYEE UPDATE
- [ ] Update event has changes object with new title

### Create Relationship

Go to Relationships via API for now:

```bash
# Get employee ID (from first response)
EMP_ID=$(curl -s http://localhost:8000/api/employees/ | jq -r '.[0].id')

# Get organization ID
ORG_ID=$(curl -s http://localhost:8000/api/organizations/ | jq -r '.[0].id')

# Create relationship
curl -X POST http://localhost:8000/api/relationships/ \
  -H "Content-Type: application/json" \
  -d "{\"employee_id\": \"$EMP_ID\", \"organization_id\": \"$ORG_ID\", \"role\": \"Lead Engineer\"}"
```

- [ ] Response shows relationship created with all fields
- [ ] Response includes id, employee_id, organization_id, role

**Verify:**
```bash
curl http://localhost:8000/api/relationships/
```
- [ ] Returns array with 1 relationship
- [ ] Shows employee_name and organization_name
- [ ] Shows role as "Lead Engineer"

### Graph Visualization

Go to Graph View (`/graph`):

- [ ] Page loads
- [ ] SVG canvas visible
- [ ] One blue node (employee John Doe)
- [ ] One green node (organization Acme Corp)
- [ ] One line connecting them
- [ ] Both nodes have labels
- [ ] Legend shows Employee and Organization colors
- [ ] Can drag nodes around
- [ ] Can zoom/pan with mouse wheel
- [ ] "Reset Zoom" button works

**API Test:**
```bash
curl http://localhost:8000/api/history/graph
```
- [ ] Returns graph object with nodes and edges arrays
- [ ] nodes has 2 items (1 employee, 1 organization)
- [ ] edges has 1 item (the relationship)
- [ ] Nodes have type, label, properties

### Timeline & History

Go to Timeline (`/timeline`):

- [ ] Page loads
- [ ] Lists events in chronological order (newest first)
- [ ] Shows at least 3 events:
  - EMPLOYEE CREATE
  - EMPLOYEE UPDATE
  - ORGANIZATION CREATE
  - RELATIONSHIP CREATE
- [ ] All events have type badge, operation badge, timestamp
- [ ] Events are color-coded (green for create, orange for update)
- [ ] Can filter by entity type dropdown
- [ ] Can filter by operation dropdown
- [ ] Filtering works correctly

**Verify filter:**
```bash
# Set filter to "EMPLOYEE" type
# Should show only employee-related events
```

- [ ] Filtered list updates
- [ ] Can clear filters

**Historical replay API test:**
```bash
# Replace with a valid timestamp from your audit events
curl "http://localhost:8000/api/history/graph/at/2026-03-03T10:48:21.916250"
```
- [ ] Returns graph object with `nodes` and `edges`
- [ ] Response is consistent with known state at that timestamp

### Delete Operations

In Employees table:

- [ ] Click "Delete" for John Doe
- [ ] Confirmation dialog appears
- [ ] Click confirm
- [ ] Employee is removed from table
- [ ] Dashboard shows 0 employees

**API Test:**
```bash
curl http://localhost:8000/api/employees/
```
- [ ] Returns empty array

**Check audit:**
```bash
curl http://localhost:8000/api/history/events?limit=100 | jq '.[] | select(.operation=="DELETE")'
```
- [ ] Shows EMPLOYEE DELETE event

## Database Verification

### Neo4j Browser

Access http://localhost:7474

Login: neo4j / password123

Run in browser:
```cypher
MATCH (e:Employee) RETURN e LIMIT 10
```
- [ ] Query returns any remaining employees
- [ ] Nodes have id, name, email, title, department properties

```cypher
MATCH (a:AuditEvent) RETURN COUNT(a) as count
```
- [ ] Shows count of audit events (should be several)

```cypher
MATCH (n) RETURN LABELS(n) as labels, COUNT(n) as count
```
- [ ] Shows node types created: Employee, Organization, AuditEvent, GraphSnapshot

```cypher
MATCH (s:GraphSnapshot) RETURN COUNT(s) as count, MAX(s.timestamp) as latest
```
- [ ] Snapshot count is >= 1 after calling `/api/history/graph/at/{timestamp}`

## Final Checks

### Error Logs

Check for any errors:

```bash
docker-compose logs backend 2>&1 | grep -i error
docker-compose logs frontend 2>&1 | grep -i error
docker-compose logs neo4j 2>&1 | grep -i error
```

- [ ] No ERROR messages

### Performance

- [ ] Frontend loads in < 2 seconds
- [ ] API responses in < 500ms
- [ ] Graph renders smoothly with 10+ nodes
- [ ] Timeline filters instantly

### Network Communication

- [ ] Frontend makes requests to http://localhost:8000
- [ ] No CORS errors in browser console
- [ ] API responses have proper Content-Type headers

## Cleanup & Restart

### Stop Services

```bash
docker-compose down
```

- [ ] All containers stopped
- [ ] No orphaned containers

### Restart Services

```bash
docker-compose up
```

- [ ] Previous data persists (Neo4j volume)
- [ ] All services start correctly
- [ ] Previous employees/orgs still there

### Clean Reset

```bash
docker-compose down -v
docker-compose up --build
```

- [ ] Fresh database (no previous data)
- [ ] All services start fresh
- [ ] Dashboard shows all 0s

## Verification Summary

| Component | Status | Notes |
|-----------|--------|-------|
| Docker Compose | ✓/✗ | |
| Neo4j Container | ✓/✗ | |
| FastAPI Backend | ✓/✗ | |
| Angular Frontend | ✓/✗ | |
| API Health | ✓/✗ | |
| Database Health | ✓/✗ | |
| Employee CRUD | ✓/✗ | |
| Organization CRUD | ✓/✗ | |
| Relationships | ✓/✗ | |
| Graph Visualization | ✓/✗ | |
| Timeline/History | ✓/✗ | |
| Audit Trail | ✓/✗ | |
| Edit Mode | ✓/✗ | |
| Data Persistence | ✓/✗ | |

---

## If Something Is Wrong

### Docker Issues
```bash
docker-compose down -v
docker system prune
docker-compose up --build
```

### Neo4j Won't Start
```bash
docker-compose logs neo4j
# Check for memory issues or port conflicts
```

### Backend API Errors
```bash
docker-compose logs backend
# Look for Python stack traces
```

### Frontend Not Connecting
```bash
# Check browser console for CORS or network errors
# Verify backend is responding: curl http://localhost:8000
```

### Reset Everything
```bash
cd c:/Users/satis/work/edit-mode-demo
docker-compose down -v
rm -rf [any local volumes]
docker-compose up --build
```

---

**All verifications passed?** Your application is ready for development! 🎉

Check out the documentation:
- [README.md](README.md) - Full docs
- [ARCHITECTURE.md](ARCHITECTURE.md) - System design
- [API_REFERENCE.md](API_REFERENCE.md) - Endpoint details
