import { Routes } from '@angular/router';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { EmployeeListComponent } from './components/employee-list/employee-list.component';
import { OrganizationListComponent } from './components/organization-list/organization-list.component';
import { GraphVisualizerComponent } from './components/graph-visualizer/graph-visualizer.component';
import { TimelineComponent } from './components/timeline/timeline.component';

export const routes: Routes = [
  { path: '', component: DashboardComponent },
  { path: 'employees', component: EmployeeListComponent },
  { path: 'organizations', component: OrganizationListComponent },
  { path: 'graph', component: GraphVisualizerComponent },
  { path: 'timeline', component: TimelineComponent },
  { path: '**', redirectTo: '' }
];
