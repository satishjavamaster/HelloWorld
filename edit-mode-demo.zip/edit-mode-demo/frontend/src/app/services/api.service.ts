import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private apiUrl = 'http://localhost:8000/api';

  constructor(private http: HttpClient) { }

  // Employee endpoints
  getEmployees(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/employees/`);
  }

  getEmployee(id: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/employees/${id}`);
  }

  createEmployee(data: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/employees/`, data);
  }

  updateEmployee(id: string, data: any): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/employees/${id}`, data);
  }

  deleteEmployee(id: string): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/employees/${id}`);
  }

  // Organization endpoints
  getOrganizations(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/organizations/`);
  }

  getOrganization(id: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/organizations/${id}`);
  }

  createOrganization(data: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/organizations/`, data);
  }

  updateOrganization(id: string, data: any): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/organizations/${id}`, data);
  }

  deleteOrganization(id: string): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/organizations/${id}`);
  }

  // Relationship endpoints
  getRelationships(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/relationships/`);
  }

  createRelationship(data: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/relationships/`, data);
  }

  updateRelationship(id: string, data: any): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/relationships/${id}`, data);
  }

  deleteRelationship(id: string): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/relationships/${id}`);
  }

  // History endpoints
  getAuditEvents(limit: number = 100): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/history/events?limit=${limit}`);
  }

  getEntityHistory(entityId: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/history/entity/${entityId}`);
  }

  getFullGraph(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/history/graph`);
  }

  getGraphAtTimestamp(timestamp: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/history/graph/at/${timestamp}`);
  }
}
