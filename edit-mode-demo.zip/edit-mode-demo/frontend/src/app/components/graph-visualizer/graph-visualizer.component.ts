import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api.service';
import * as d3 from 'd3';

interface Node {
  id: string;
  label: string;
  type: 'employee' | 'organization';
  properties?: any;
  x?: number;
  y?: number;
  fx?: number | null;
  fy?: number | null;
}

interface Link {
  source: string | Node;
  target: string | Node;
  label: string;
}

@Component({
  selector: 'app-graph-visualizer',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="graph-container">
      <h1>Organization Structure</h1>
      <div class="controls">
        <button (click)="resetZoom()" class="btn btn-sm">Reset Zoom</button>
        <button (click)="refreshGraph()" class="btn btn-sm">Refresh</button>
      </div>
      <svg #graphSvg class="graph-svg"></svg>
      <div class="legend">
        <div class="legend-item">
          <div class="legend-color employee"></div>
          <span>Employee</span>
        </div>
        <div class="legend-item">
          <div class="legend-color organization"></div>
          <span>Organization</span>
        </div>
      </div>
    </div>
  `,
  styleUrls: ['./graph-visualizer.component.scss']
})
export class GraphVisualizerComponent implements OnInit {
  @ViewChild('graphSvg', { static: false }) graphSvg!: ElementRef;

  nodes: Node[] = [];
  links: Link[] = [];
  simulation: any;

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
    this.loadGraphData();
  }

  loadGraphData(): void {
    this.apiService.getFullGraph().subscribe(
      (data) => {
        this.nodes = data.nodes || [];
        this.links = data.edges.map((edge: any) => ({
          source: this.nodes.find(n => n.id === edge.source),
          target: this.nodes.find(n => n.id === edge.target),
          label: edge.label || 'works for'
        }));
        this.initializeGraph();
      },
      (error) => console.error('Error loading graph data:', error)
    );
  }

  initializeGraph(): void {
    if (!this.graphSvg) return;

    const width = 1000;
    const height = 700;

    // Clear previous content
    const svgElement = this.graphSvg.nativeElement;
    d3.select(svgElement).selectAll('*').remove();

    const svg = d3.select(svgElement)
      .attr('width', width)
      .attr('height', height);

    // Create simulation
    this.simulation = d3.forceSimulation(this.nodes as any[])
      .force('link', d3.forceLink(this.links).id((d: any) => d.id).distance(150))
      .force('charge', d3.forceManyBody().strength(-300))
      .force('center', d3.forceCenter(width / 2, height / 2))
      .force('collide', d3.forceCollide().radius(40));

    // Add zoom
    const g = svg.append('g');
    svg.call(d3.zoom<SVGSVGElement, unknown>().on('zoom', (event) => {
      g.attr('transform', event.transform);
    }) as any);

    // Draw links
    const link = g.selectAll('.link')
      .data(this.links)
      .enter()
      .append('line')
      .attr('class', 'link')
      .attr('stroke', '#999')
      .attr('stroke-opacity', 0.6)
      .attr('stroke-width', 2);

    // Draw nodes
    const node = g.selectAll('.node')
      .data(this.nodes)
      .enter()
      .append('circle')
      .attr('class', (d: Node) => `node ${d.type}`)
      .attr('r', 25)
      .attr('fill', (d: Node) => d.type === 'employee' ? '#667eea' : '#4CAF50')
      .call(d3.drag<SVGCircleElement, Node>()
        .on('start', (event, d) => {
          if (!event.active) this.simulation.alphaTarget(0.3).restart();
          d.fx = d.x;
          d.fy = d.y;
        })
        .on('drag', (event, d) => {
          d.fx = event.x;
          d.fy = event.y;
        })
        .on('end', (event, d) => {
          if (!event.active) this.simulation.alphaTarget(0);
          d.fx = null;
          d.fy = null;
        }) as any);

    // Add labels
    const labels = g.selectAll('.label')
      .data(this.nodes)
      .enter()
      .append('text')
      .attr('class', 'label')
      .text((d: Node) => d.label)
      .attr('text-anchor', 'middle')
      .attr('dy', '.3em')
      .attr('fill', 'white')
      .style('font-size', '11px')
      .style('font-weight', 'bold')
      .style('pointer-events', 'none');

    // Update positions on tick
    this.simulation.on('tick', () => {
      link
        .attr('x1', (d: any) => d.source.x)
        .attr('y1', (d: any) => d.source.y)
        .attr('x2', (d: any) => d.target.x)
        .attr('y2', (d: any) => d.target.y);

      node
        .attr('cx', (d: any) => d.x)
        .attr('cy', (d: any) => d.y);

      labels
        .attr('x', (d: any) => d.x)
        .attr('y', (d: any) => d.y);
    });
  }

  refreshGraph(): void {
    this.loadGraphData();
  }

  resetZoom(): void {
    if (this.graphSvg) {
      const svg = d3.select(this.graphSvg.nativeElement);
      svg.transition()
        .duration(750)
        .call(d3.zoom<SVGSVGElement, unknown>().transform as any, d3.zoomIdentity.translate(0, 0));
    }
  }
}
