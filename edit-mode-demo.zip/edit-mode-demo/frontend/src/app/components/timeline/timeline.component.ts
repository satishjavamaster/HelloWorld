import { Component, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';
import * as d3 from 'd3';

@Component({
  selector: 'app-timeline',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="timeline-container">
      <h1>Edit Timeline &amp; History</h1>
      
      <div class="timeline-controls">
        <div class="time-filter">
          <label>Filter by type:</label>
          <select [(ngModel)]="selectedType" (change)="filterEvents()" name="type">
            <option value="">All Events</option>
            <option value="EMPLOYEE">Employee</option>
            <option value="ORGANIZATION">Organization</option>
            <option value="RELATIONSHIP">Relationship</option>
          </select>
        </div>
        <div class="time-filter">
          <label>Filter by operation:</label>
          <select [(ngModel)]="selectedOperation" (change)="filterEvents()" name="operation">
            <option value="">All Operations</option>
            <option value="CREATE">Create</option>
            <option value="UPDATE">Update</option>
            <option value="DELETE">Delete</option>
          </select>
        </div>
      </div>

      <div class="timeline-view">
        <div *ngIf="filteredEvents.length === 0" class="empty-state">
          <p>No events found</p>
        </div>

        <div *ngFor="let event of filteredEvents; let i = index" class="timeline-item" [ngClass]="event.operation.toLowerCase()">
          <div class="timeline-marker"></div>
          <div class="timeline-content">
            <div class="event-header">
              <span class="event-type" [ngClass]="event.entity_type.toLowerCase()">{{ event.entity_type }}</span>
              <span class="event-operation" [ngClass]="event.operation.toLowerCase()">{{ event.operation }}</span>
              <span class="event-time">{{ formatDate(event.timestamp) }}</span>
            </div>
            <div class="event-details">
              <p><strong>Entity ID:</strong> <span class="entity-id">{{ event.entity_id }}</span></p>
              <div *ngIf="event.changes" class="changes-section">
                <p class="changes-label" (click)="toggleChanges(i)">
                  <span class="toggle-icon">{{ expandedChanges[i] ? '▼' : '▶' }}</span>
                  <strong>Changes</strong>
                  <span class="change-count">({{ getObjectKeys(event.changes).length }} fields)</span>
                </p>
                <div class="changes-tree" *ngIf="expandedChanges[i]">
                  <div *ngFor="let key of getObjectKeys(event.changes)" class="tree-node">
                    <span class="tree-key">{{ key }}</span>
                    <span class="tree-sep">:</span>
                    <span class="tree-value" [ngClass]="getValueType(getChangeValue(event.changes, key))">{{ formatValue(getChangeValue(event.changes, key)) }}</span>
                  </div>
                </div>
              </div>
            </div>
            <button class="btn btn-sm btn-info" (click)="viewGraphAtTime(event.timestamp)">
              View Graph State
            </button>
          </div>
        </div>
      </div>

      <!-- Graph State Modal -->
      <div class="graph-modal-overlay" *ngIf="showGraphModal" (click)="closeGraphModal()">
        <div class="graph-modal" (click)="$event.stopPropagation()">
          <div class="graph-modal-header">
            <h2>Graph State at {{ graphTimestampLabel }}</h2>
            <button class="btn-close" (click)="closeGraphModal()">&times;</button>
          </div>
          <div class="graph-modal-body">
            <div *ngIf="graphLoading" class="graph-loading">Loading graph...</div>
            <div *ngIf="graphError" class="graph-error">{{ graphError }}</div>
            <div class="graph-stats" *ngIf="!graphLoading && !graphError">
              <span class="stat"><strong>{{ graphData?.nodes?.length || 0 }}</strong> nodes</span>
              <span class="stat"><strong>{{ graphData?.edges?.length || 0 }}</strong> relationships</span>
            </div>
            <svg #modalGraphSvg class="modal-graph-svg" *ngIf="!graphLoading && !graphError"></svg>
            <div class="graph-legend" *ngIf="!graphLoading && !graphError">
              <div class="legend-item"><span class="legend-dot employee"></span> Employee</div>
              <div class="legend-item"><span class="legend-dot organization"></span> Organization</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styleUrls: ['./timeline.component.scss']
})
export class TimelineComponent implements OnInit {
  @ViewChild('modalGraphSvg', { static: false }) modalGraphSvg!: ElementRef;

  allEvents: any[] = [];
  filteredEvents: any[] = [];
  selectedType: string = '';
  selectedOperation: string = '';
  expandedChanges: { [key: number]: boolean } = {};

  // Graph modal state
  showGraphModal = false;
  graphLoading = false;
  graphError = '';
  graphData: any = null;
  graphTimestampLabel = '';
  private simulation: any;

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
    this.loadEvents();
  }

  loadEvents(): void {
    this.apiService.getAuditEvents(500).subscribe(
      (data) => {
        this.allEvents = data.sort((a: any, b: any) => 
          new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
        );
        this.filteredEvents = [...this.allEvents];
      },
      (error: any) => console.error('Error loading events:', error)
    );
  }

  filterEvents(): void {
    this.filteredEvents = this.allEvents.filter(event => {
      const typeMatch = !this.selectedType || event.entity_type === this.selectedType;
      const operationMatch = !this.selectedOperation || event.operation === this.selectedOperation;
      return typeMatch && operationMatch;
    });
  }

  formatDate(dateString: string): string {
    const date = new Date(dateString);
    return date.toLocaleString();
  }

  getObjectKeys(obj: any): string[] {
    const parsed = this.parseChanges(obj);
    return parsed ? Object.keys(parsed) : [];
  }

  parseChanges(obj: any): any {
    if (!obj) return null;
    if (typeof obj === 'string') {
      try { return JSON.parse(obj); } catch { return null; }
    }
    if (typeof obj === 'object') return obj;
    return null;
  }

  getChangeValue(changes: any, key: string): any {
    const parsed = this.parseChanges(changes);
    return parsed ? parsed[key] : null;
  }

  toggleChanges(index: number): void {
    this.expandedChanges[index] = !this.expandedChanges[index];
  }

  formatValue(value: any): string {
    if (value === null || value === undefined) return 'null';
    if (typeof value === 'string') return value;
    if (typeof value === 'object') return JSON.stringify(value);
    return String(value);
  }

  getValueType(value: any): string {
    if (value === null || value === undefined) return 'val-null';
    if (typeof value === 'number') return 'val-number';
    if (typeof value === 'boolean') return 'val-boolean';
    if (typeof value === 'string') return 'val-string';
    return 'val-object';
  }

  viewGraphAtTime(timestamp: string): void {
    this.showGraphModal = true;
    this.graphLoading = true;
    this.graphError = '';
    this.graphData = null;
    this.graphTimestampLabel = this.formatDate(timestamp);

    this.apiService.getGraphAtTimestamp(timestamp).subscribe(
      (data) => {
        this.graphData = data;
        this.graphLoading = false;
        // Need a tick for the SVG element to render before we draw
        setTimeout(() => this.renderGraphModal(), 50);
      },
      (error: any) => {
        console.error('Error loading graph at timestamp:', error);
        this.graphLoading = false;
        this.graphError = 'Failed to load graph state. Please try again.';
      }
    );
  }

  closeGraphModal(): void {
    this.showGraphModal = false;
    if (this.simulation) {
      this.simulation.stop();
      this.simulation = null;
    }
  }

  private renderGraphModal(): void {
    if (!this.modalGraphSvg) return;

    const nodes = (this.graphData?.nodes || []).map((n: any) => ({ ...n }));
    const edges = this.graphData?.edges || [];

    if (nodes.length === 0) {
      this.graphError = 'No nodes in graph at this time.';
      return;
    }

    const svgEl = this.modalGraphSvg.nativeElement;
    const width = 700;
    const height = 450;

    d3.select(svgEl).selectAll('*').remove();
    const svg = d3.select(svgEl).attr('width', width).attr('height', height);
    const g = svg.append('g');

    // Zoom
    svg.call(d3.zoom<SVGSVGElement, unknown>().scaleExtent([0.3, 3]).on('zoom', (event) => {
      g.attr('transform', event.transform);
    }) as any);

    // Build links referencing node objects
    const links = edges.map((e: any) => ({
      source: nodes.find((n: any) => n.id === e.source) || e.source,
      target: nodes.find((n: any) => n.id === e.target) || e.target,
      label: e.label || 'works for'
    })).filter((l: any) => l.source && l.target);

    this.simulation = d3.forceSimulation(nodes)
      .force('link', d3.forceLink(links).id((d: any) => d.id).distance(120))
      .force('charge', d3.forceManyBody().strength(-250))
      .force('center', d3.forceCenter(width / 2, height / 2))
      .force('collide', d3.forceCollide().radius(35));

    // Links
    const link = g.selectAll('.link').data(links).enter().append('line')
      .attr('class', 'link')
      .attr('stroke', '#aaa')
      .attr('stroke-opacity', 0.6)
      .attr('stroke-width', 2);

    // Link labels
    const linkLabel = g.selectAll('.link-label').data(links).enter().append('text')
      .attr('class', 'link-label')
      .text((d: any) => d.label)
      .attr('text-anchor', 'middle')
      .style('font-size', '9px')
      .style('fill', '#888');

    // Nodes
    const node = g.selectAll('.node').data(nodes).enter().append('circle')
      .attr('r', 20)
      .attr('fill', (d: any) => d.type === 'employee' ? '#667eea' : '#4CAF50')
      .attr('stroke', '#fff')
      .attr('stroke-width', 2)
      .call(d3.drag<SVGCircleElement, any>()
        .on('start', (event: any, d: any) => {
          if (!event.active) this.simulation.alphaTarget(0.3).restart();
          d.fx = d.x; d.fy = d.y;
        })
        .on('drag', (event: any, d: any) => { d.fx = event.x; d.fy = event.y; })
        .on('end', (event: any, d: any) => {
          if (!event.active) this.simulation.alphaTarget(0);
          d.fx = null; d.fy = null;
        }) as any);

    // Node labels
    const label = g.selectAll('.node-label').data(nodes).enter().append('text')
      .text((d: any) => d.label)
      .attr('text-anchor', 'middle')
      .attr('dy', '.35em')
      .style('font-size', '10px')
      .style('fill', 'white')
      .style('font-weight', 'bold')
      .style('pointer-events', 'none');

    // Tooltip on hover
    node.append('title').text((d: any) => `${d.type}: ${d.label}`);

    this.simulation.on('tick', () => {
      link.attr('x1', (d: any) => d.source.x).attr('y1', (d: any) => d.source.y)
          .attr('x2', (d: any) => d.target.x).attr('y2', (d: any) => d.target.y);
      linkLabel.attr('x', (d: any) => (d.source.x + d.target.x) / 2)
               .attr('y', (d: any) => (d.source.y + d.target.y) / 2);
      node.attr('cx', (d: any) => d.x).attr('cy', (d: any) => d.y);
      label.attr('x', (d: any) => d.x).attr('y', (d: any) => d.y);
    });
  }
}
