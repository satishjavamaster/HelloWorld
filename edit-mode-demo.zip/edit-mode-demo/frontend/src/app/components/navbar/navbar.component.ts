import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <nav class="navbar">
      <div class="navbar-brand">
        <h1>OrgChart Manager</h1>
      </div>
      <ul class="navbar-menu">
        <li><a routerLink="/" routerLinkActive="active" [routerLinkActiveOptions]="{exact: true}">Dashboard</a></li>
        <li><a routerLink="/employees" routerLinkActive="active">Employees</a></li>
        <li><a routerLink="/organizations" routerLinkActive="active">Organizations</a></li>
        <li><a routerLink="/graph" routerLinkActive="active">Graph View</a></li>
        <li><a routerLink="/timeline" routerLinkActive="active">Timeline</a></li>
        <li><a routerLink="/planner" routerLinkActive="active">Planner</a></li>
      </ul>
    </nav>
  `,
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {
  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
  }
}
