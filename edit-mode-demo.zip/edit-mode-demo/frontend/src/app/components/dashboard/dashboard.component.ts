import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="dashboard">
      <h1>Dashboard</h1>
      <div class="stats-grid">
        <div class="stat-card">
          <h3>Total Employees</h3>
          <p class="stat-number">{{ totalEmployees }}</p>
        </div>
        <div class="stat-card">
          <h3>Total Organizations</h3>
          <p class="stat-number">{{ totalOrganizations }}</p>
        </div>
        <div class="stat-card">
          <h3>Total Relationships</h3>
          <p class="stat-number">{{ totalRelationships }}</p>
        </div>
        <div class="stat-card">
          <h3>Recent Changes</h3>
          <p class="stat-number">{{ recentChanges }}</p>
        </div>
      </div>
    </div>
  `,
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  totalEmployees: number = 0;
  totalOrganizations: number = 0;
  totalRelationships: number = 0;
  recentChanges: number = 0;

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
    this.loadStats();
  }

  loadStats(): void {
    this.apiService.getEmployees().subscribe(
      (employees) => this.totalEmployees = employees.length,
      (error) => console.error('Error loading employees:', error)
    );

    this.apiService.getOrganizations().subscribe(
      (orgs) => this.totalOrganizations = orgs.length,
      (error) => console.error('Error loading organizations:', error)
    );

    this.apiService.getRelationships().subscribe(
      (rels) => this.totalRelationships = rels.length,
      (error) => console.error('Error loading relationships:', error)
    );

    this.apiService.getAuditEvents(10).subscribe(
      (events) => this.recentChanges = events.length,
      (error) => console.error('Error loading audit events:', error)
    );
  }
}
