import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-organization-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="org-container">
      <h1>Organization Management</h1>
      
      <div class="form-section" *ngIf="editMode">
        <h2>{{ selectedOrg ? 'Edit Organization' : 'Add New Organization' }}</h2>
        <form (ngSubmit)="onSubmit()">
          <div class="form-group">
            <label>Name *</label>
            <input type="text" [(ngModel)]="formData.name" name="name" required>
          </div>
          <div class="form-group">
            <label>Description</label>
            <textarea [(ngModel)]="formData.description" name="description"></textarea>
          </div>
          <div class="form-group">
            <label>Location</label>
            <input type="text" [(ngModel)]="formData.location" name="location">
          </div>
          <div class="form-actions">
            <button type="submit" class="btn btn-primary">Save</button>
            <button type="button" class="btn btn-secondary" (click)="cancelEdit()">Cancel</button>
          </div>
        </form>
      </div>

      <div class="modal modal-visible" *ngIf="showLinkModal">
        <div class="modal-content">
          <div class="modal-header">
            <h2>Assign Employee to {{ selectedOrg?.name }}</h2>
            <button class="btn-close" (click)="closeLinkModal()">×</button>
          </div>
          <div class="modal-body">
            <div class="form-group">
              <label>Select Employee *</label>
              <select [(ngModel)]="linkFormData.employee_id" name="employee" required>
                <option value="">-- Choose Employee --</option>
                <option *ngFor="let emp of employees" [value]="emp.id">
                  {{ emp.name }} ({{ emp.title }})
                </option>
              </select>
            </div>
            <div class="form-group">
              <label>Role</label>
              <input type="text" [(ngModel)]="linkFormData.role" name="role" placeholder="e.g., Manager, Developer, etc.">
            </div>

            <div class="form-group">
              <label>Current Associations</label>
              <p *ngIf="orgRelationships.length === 0">No employee assigned.</p>
              <div *ngFor="let rel of orgRelationships" class="current-association-row">
                <span>{{ rel.employee_name }} <small>({{ rel.role || 'member' }})</small></span>
                <button class="btn btn-sm btn-delete" (click)="unassign(rel)">Unassign</button>
              </div>
            </div>
          </div>
          <div class="modal-actions">
            <button class="btn btn-primary" (click)="submitLink()" [disabled]="!linkFormData.employee_id">
              Create Assignment
            </button>
            <button class="btn btn-secondary" (click)="closeLinkModal()">Cancel</button>
          </div>
        </div>
      </div>

      <div class="list-section">
        <div class="section-header">
          <h2>Organizations</h2>
          <button class="btn btn-primary" (click)="startNew()">+ Add Organization</button>
        </div>

        <div *ngIf="organizations.length === 0" class="empty-state">
          <p>No organizations found. <a href="#" (click)="startNew(); $event.preventDefault()">Create one</a></p>
        </div>

        <table *ngIf="organizations.length > 0" class="organizations-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Description</th>
              <th>Location</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let org of organizations">
              <td>{{ org.name }}</td>
              <td>{{ org.description || '-' }}</td>
              <td>{{ org.location || '-' }}</td>
              <td class="actions">
                <button class="btn btn-sm btn-link" (click)="openLinkModal(org)" title="Assign Employee">
                  Assign
                </button>
                <button class="btn btn-sm btn-edit" (click)="edit(org)">Edit</button>
                <button class="btn btn-sm btn-delete" (click)="delete(org.id)">Delete</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `,
  styleUrls: ['./organization-list.component.scss']
})
export class OrganizationListComponent implements OnInit {
  organizations: any[] = [];
  employees: any[] = [];
  relationships: any[] = [];
  editMode = false;
  showLinkModal = false;
  selectedOrg: any = null;
  formData = { name: '', description: '', location: '' };
  linkFormData = { employee_id: '', role: '' };

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
    this.loadOrganizations();
    this.loadEmployees();
    this.loadRelationships();
  }

  loadOrganizations(): void {
    this.apiService.getOrganizations().subscribe(
      (data) => this.organizations = data,
      (error) => console.error('Error loading organizations:', error)
    );
  }

  loadEmployees(): void {
    this.apiService.getEmployees().subscribe(
      (data) => this.employees = data,
      (error) => console.error('Error loading employees:', error)
    );
  }

  loadRelationships(): void {
    this.apiService.getRelationships().subscribe(
      (data) => this.relationships = data,
      (error) => console.error('Error loading relationships:', error)
    );
  }

  get orgRelationships(): any[] {
    if (!this.selectedOrg) {
      return [];
    }
    return this.relationships.filter(
      (rel) => rel.organization_id === this.selectedOrg.id
    );
  }

  startNew(): void {
    this.editMode = true;
    this.selectedOrg = null;
    this.formData = { name: '', description: '', location: '' };
  }

  edit(org: any): void {
    this.editMode = true;
    this.selectedOrg = org;
    this.formData = { ...org };
  }

  cancelEdit(): void {
    this.editMode = false;
    this.selectedOrg = null;
    this.formData = { name: '', description: '', location: '' };
  }

  openLinkModal(org: any): void {
    this.selectedOrg = org;
    this.linkFormData = { employee_id: '', role: '' };
    this.loadRelationships();
    this.showLinkModal = true;
  }

  closeLinkModal(): void {
    this.showLinkModal = false;
    this.selectedOrg = null;
    this.linkFormData = { employee_id: '', role: '' };
  }

  submitLink(): void {
    if (this.selectedOrg && this.linkFormData.employee_id) {
      const relationshipData = {
        employee_id: this.linkFormData.employee_id,
        organization_id: this.selectedOrg.id,
        role: this.linkFormData.role || 'member'
      };

      this.apiService.createRelationship(relationshipData).subscribe(
        () => {
          const emp = this.employees.find(e => e.id === this.linkFormData.employee_id);
          alert(`${emp?.name} has been assigned to ${this.selectedOrg.name}!`);
          this.loadRelationships();
          this.closeLinkModal();
        },
        (error: any) => {
          console.error('Error creating relationship:', error);
          alert('Failed to create assignment. Please try again.');
        }
      );
    }
  }

  unassign(relationship: any): void {
    if (!relationship?.id) {
      return;
    }

    if (confirm(`Unassign ${relationship.employee_name} from ${relationship.organization_name}?`)) {
      this.apiService.deleteRelationship(relationship.id).subscribe(
        () => {
          this.loadRelationships();
          alert('Association removed successfully.');
        },
        (error: any) => {
          console.error('Error removing relationship:', error);
          alert('Failed to remove association. Please try again.');
        }
      );
    }
  }

  onSubmit(): void {
    if (this.selectedOrg) {
      this.apiService.updateOrganization(this.selectedOrg.id, this.formData).subscribe(
        () => {
          this.loadOrganizations();
          this.cancelEdit();
        },
        (error: any) => console.error('Error updating organization:', error)
      );
    } else {
      this.apiService.createOrganization(this.formData).subscribe(
        () => {
          this.loadOrganizations();
          this.cancelEdit();
        },
        (error: any) => console.error('Error creating organization:', error)
      );
    }
  }

  delete(id: string): void {
    if (confirm('Are you sure you want to delete this organization?')) {
      this.apiService.deleteOrganization(id).subscribe(
        () => this.loadOrganizations(),
        (error: any) => console.error('Error deleting organization:', error)
      );
    }
  }
}
