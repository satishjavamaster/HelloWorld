import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-employee-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.scss']
})
export class EmployeeListComponent implements OnInit {
  employees: any[] = [];
  organizations: any[] = [];
  relationships: any[] = [];
  editMode = false;
  showLinkModal = false;
  selectedEmployee: any = null;
  formData = { name: '', email: '', title: '', department: '' };
  linkFormData = { organization_id: '', role: '' };

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
    this.loadEmployees();
    this.loadOrganizations();
    this.loadRelationships();
  }

  loadEmployees(): void {
    this.apiService.getEmployees().subscribe(
      (data: any[]) => this.employees = data,
      (error: any) => console.error('Error loading employees:', error)
    );
  }

  loadOrganizations(): void {
    this.apiService.getOrganizations().subscribe(
      (data: any[]) => this.organizations = data,
      (error: any) => console.error('Error loading organizations:', error)
    );
  }

  loadRelationships(): void {
    this.apiService.getRelationships().subscribe(
      (data: any[]) => this.relationships = data,
      (error: any) => console.error('Error loading relationships:', error)
    );
  }

  get employeeRelationships(): any[] {
    if (!this.selectedEmployee) {
      return [];
    }
    return this.relationships.filter(
      (rel) => rel.employee_id === this.selectedEmployee.id
    );
  }

  startNew(): void {
    this.editMode = true;
    this.selectedEmployee = null;
    this.formData = { name: '', email: '', title: '', department: '' };
  }

  edit(employee: any): void {
    this.editMode = true;
    this.selectedEmployee = employee;
    this.formData = { ...employee };
  }

  cancelEdit(): void {
    this.editMode = false;
    this.selectedEmployee = null;
    this.formData = { name: '', email: '', title: '', department: '' };
  }

  openLinkModal(employee: any): void {
    this.selectedEmployee = employee;
    this.linkFormData = { organization_id: '', role: '' };
    this.loadRelationships();
    this.showLinkModal = true;
  }

  closeLinkModal(): void {
    this.showLinkModal = false;
    this.selectedEmployee = null;
    this.linkFormData = { organization_id: '', role: '' };
  }

  submitLink(): void {
    if (this.selectedEmployee && this.linkFormData.organization_id) {
      const relationshipData = {
        employee_id: this.selectedEmployee.id,
        organization_id: this.linkFormData.organization_id,
        role: this.linkFormData.role || 'member'
      };

      this.apiService.createRelationship(relationshipData).subscribe(
        () => {
          alert(`${this.selectedEmployee.name} has been linked to the organization!`);
          this.loadRelationships();
          this.closeLinkModal();
        },
        (error: any) => {
          console.error('Error creating relationship:', error);
          alert('Failed to create link. Please try again.');
        }
      );
    }
  }

  unassign(relationship: any): void {
    if (!relationship?.id) {
      return;
    }

    if (confirm(`Unassign ${relationship.employee_name} from ${relationship.organization_name}?`)) {
      this.apiService.deleteRelationship(relationship.id).subscribe(
        () => {
          this.loadRelationships();
          alert('Association removed successfully.');
        },
        (error: any) => {
          console.error('Error removing relationship:', error);
          alert('Failed to remove association. Please try again.');
        }
      );
    }
  }

  onSubmit(): void {
    if (this.selectedEmployee) {
      this.apiService.updateEmployee(this.selectedEmployee.id, this.formData).subscribe(
        () => {
          this.loadEmployees();
          this.cancelEdit();
        },
          (error: any) => console.error('Error updating employee:', error)
      );
    } else {
      this.apiService.createEmployee(this.formData).subscribe(
        () => {
          this.loadEmployees();
          this.cancelEdit();
        },
          (error: any) => console.error('Error creating employee:', error)
      );
    }
  }

  delete(id: string): void {
    if (confirm('Are you sure you want to delete this employee?')) {
      this.apiService.deleteEmployee(id).subscribe(
        () => this.loadEmployees(),
        (error: any) => console.error('Error deleting employee:', error)
      );
    }
  }
}
