# Quick Start Guide

## Prerequisites
- Docker & Docker Compose
- Ports 7474, 7687 (Neo4j), 8000 (Backend), 4200 (Frontend) available

## Quick Start

### On Linux/Mac:
```bash
chmod +x start.sh
./start.sh
```

### On Windows (PowerShell):
```powershell
docker-compose up -d
```

Wait for services to start (about 30 seconds), then open:
- Frontend: http://localhost:4200
- API Docs: http://localhost:8000/docs
- Neo4j Browser: http://localhost:7474

## First Steps

1. **Create an Organization**
   - Go to Organizations page
   - Click "+ Add Organization"
   - Fill in name, description, location
   - Save

2. **Create Employees**
   - Go to Employees page
   - Click "+ Add Employee"
   - Fill in name, email, title, department
   - Save

3. **Create Relationships**
   - Frontend: Open Relationships (via API or manual creation)
   - Create relationship between employee and organization
   - Set role (member, manager, etc.)

4. **View Graph**
   - Go to Graph View page
   - See D3 force-directed graph
   - Drag nodes to rearrange
   - Zoom and pan

5. **Check History**
   - Go to Timeline page
   - See all events with filters
   - Filter by type, operation
   - Click "View Graph State" to see historical snapshot

## Stopping

```bash
docker-compose down
```

To completely remove volumes:
```bash
docker-compose down -v
```

## Troubleshooting

### If containers don't start:
```bash
docker-compose logs
```

### If API is not responding:
```bash
docker-compose logs backend
```

### If Neo4j won't connect:
```bash
docker-compose logs neo4j
# Check health
docker-compose ps
```

### Reset everything:
```bash
docker-compose down -v
docker-compose up --build
```

## API Endpoints (For Manual Testing)

### Create Employee
```bash
curl -X POST http://localhost:8000/api/employees/ \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Doe",
    "email": "john@example.com",
    "title": "Software Engineer",
    "department": "Engineering"
  }'
```

### Get All Employees
```bash
curl http://localhost:8000/api/employees/
```

### Get Full Graph
```bash
curl http://localhost:8000/api/history/graph
```

### Get Audit Events
```bash
curl http://localhost:8000/api/history/events
```

## Features Overview

- **Dashboard**: Statistics overview
- **Employees**: CRUD with edit mode
- **Organizations**: CRUD with edit mode
- **Relationships**: Connect employees to organizations
- **Graph Visualization**: D3 force-directed graph with interactions
- **Timeline**: Complete audit trail of all changes
- **History**: Filter events by type and operation
- **Historical States**: View graph state at any point in time

## Next Steps

1. Customize edit mode UI (./frontend/src/app/components/)
2. Add more complex graph algorithms (Neo4j)
3. Implement real-time updates (WebSockets)
4. Add user authentication
5. Enhance timeline with animations
6. Add export/import functionality

See README.md for detailed documentation.
