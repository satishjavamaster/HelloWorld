import asyncio
from app.services.database import db_manager
from neo4j import AsyncGraphDatabase
from app.config import settings
import uuid
from datetime import datetime

async def test_direct():
    """Test organization creation directly"""
    drv = AsyncGraphDatabase.driver(
        settings.neo4j_uri,
        auth=(settings.neo4j_user, settings.neo4j_password)
    )
    
    org_id = str(uuid.uuid4())
    now = datetime.utcnow().isoformat()
    
    query = """
    CREATE (o:Organization {
        id: $id,
        name: $name,
        description: $description,
        location: $location,
        created_at: $created_at,
        updated_at: $updated_at
    })
    RETURN o
    """
    
    params = {
        'id': org_id,
        'name': 'Direct Test Org',
        'description': 'Direct Test',
        'location': 'Building D',
        'created_at': now,
        'updated_at': now
    }
    
    async with drv.session() as s:
        try:
            result = await s.run(query, params)
            record = await result.single()
            print('SUCCESS:', record)
        except Exception as e:
            print('ERROR:', type(e).__name__, str(e))
    
    await drv.close()

asyncio.run(test_direct())
