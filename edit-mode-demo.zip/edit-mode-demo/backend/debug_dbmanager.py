import asyncio
from app.services.database import db_manager
import uuid
from datetime import datetime

async def test_with_db_manager():
    """Test organization creation using DatabaseManager"""
    await db_manager.connect()
    
    org_id = str(uuid.uuid4())
    now = datetime.utcnow().isoformat()
    
    query = """
    CREATE (o:Organization {
        id: $id,
        name: $name,
        description: $description,
        location: $location,
        created_at: $created_at,
        updated_at: $updated_at
    })
    RETURN o
    """
    
    params = {
        'id': org_id,
        'name': 'DBManager Test Org',
        'description': 'DBManager Test',
        'location': 'Building E',
        'created_at': now,
        'updated_at': now
    }
    
    try:
        result = await db_manager.execute(query, params)
        print('SUCCESS: Records:', len(result))
        if result:
            print('First record:', result[0])
    except Exception as e:
        print('ERROR:', type(e).__name__, str(e))

asyncio.run(test_with_db_manager())
