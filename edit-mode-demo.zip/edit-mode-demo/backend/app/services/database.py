from neo4j import AsyncGraphDatabase, GraphDatabase
from app.config import settings
import uuid
from datetime import datetime
from typing import Optional, Dict, Any, List
import json

def node_to_dict(node) -> Dict:
    """Convert Neo4j node to dictionary"""
    # Neo4j `Node` objects expose a .data() method which returns the
    # property map.  Simply calling `dict(node)` sometimes produces
    # an empty dict because the node implements a mapping protocol that
    # doesn't iterate over its properties.  Previously we attempted to
    # convert any object with a __dict__, which caused employee/organization
    # lookups to return `{}` even though the node existed in the database.
    #
    # To handle all cases we check for a few known interfaces in order of
    # preference.
    if hasattr(node, 'data') and callable(node.data):
        return node.data()
    if isinstance(node, dict):
        return node
    try:
        return dict(node)
    except Exception:
        # fallback to empty dict if conversion fails
        return {}

class DatabaseManager:
    def __init__(self):
        self.driver = None
    
    async def connect(self):
        self.driver = AsyncGraphDatabase.driver(
            settings.neo4j_uri,
            auth=(settings.neo4j_user, settings.neo4j_password)
        )
    
    async def close(self):
        if self.driver:
            await self.driver.close()
    
    async def execute(self, query: str, parameters: Dict = None):
        async with self.driver.session() as session:
            result = await session.run(query, parameters or {})
            eager_result = await result.to_eager_result()
            return eager_result.records
    
    async def get_single(self, query: str, parameters: Dict = None):
        async with self.driver.session() as session:
            result = await session.run(query, parameters or {})
            record = await result.single()
            return record[0] if record else None

db_manager = DatabaseManager()

async def init_db():
    """Initialize database connection and create constraints"""
    await db_manager.connect()
    
    # Create constraints and indexes
    async with db_manager.driver.session() as session:
        queries = [
            "CREATE CONSTRAINT employee_id IF NOT EXISTS FOR (e:Employee) REQUIRE e.id IS UNIQUE",
            "CREATE CONSTRAINT organization_id IF NOT EXISTS FOR (o:Organization) REQUIRE o.id IS UNIQUE",
            "CREATE CONSTRAINT audit_id IF NOT EXISTS FOR (a:AuditEvent) REQUIRE a.id IS UNIQUE",
            "CREATE INDEX employee_email IF NOT EXISTS FOR (e:Employee) ON (e.email)",
            "CREATE INDEX organization_name IF NOT EXISTS FOR (o:Organization) ON (o.name)",
        ]
        
        for query in queries:
            try:
                await session.run(query)
            except Exception as e:
                print(f"Constraint/Index creation note: {e}")

class EmployeeService:
    @staticmethod
    async def create_employee(name: str, email: str, title: str, department: Optional[str] = None) -> Dict:
        emp_id = str(uuid.uuid4())
        now = datetime.utcnow().isoformat()
        
        query = """
        CREATE (e:Employee {
            id: $id,
            name: $name,
            email: $email,
            title: $title,
            department: $department,
            created_at: $created_at,
            updated_at: $updated_at
        })
        RETURN e
        """
        
        result = await db_manager.execute(query, {
            "id": emp_id,
            "name": name,
            "email": email,
            "title": title,
            "department": department,
            "created_at": now,
            "updated_at": now
        })
        
        # Create audit event
        await AuditService.log_event(
            entity_type="EMPLOYEE",
            entity_id=emp_id,
            operation="CREATE",
            changes={"name": name, "email": email, "title": title, "department": department},
            changed_by="system"
        )
        
        return {"id": emp_id, "name": name, "email": email, "title": title, "department": department}
    
    @staticmethod
    async def get_employee(emp_id: str) -> Optional[Dict]:
        query = "MATCH (e:Employee {id: $id}) RETURN e"
        result = await db_manager.get_single(query, {"id": emp_id})
        if result:
            return node_to_dict(result)
        return None
    
    @staticmethod
    async def get_all_employees() -> List[Dict]:
        query = "MATCH (e:Employee) RETURN e ORDER BY e.name"
        result = await db_manager.execute(query)
        return [node_to_dict(record[0]) for record in result] if result else []
    
    @staticmethod
    async def update_employee(emp_id: str, updates: Dict) -> Optional[Dict]:
        now = datetime.utcnow().isoformat()
        
        set_clause = ", ".join([f"e.{k} = ${k}" for k in updates.keys()])
        set_clause += ", e.updated_at = $updated_at"
        
        query = f"""
        MATCH (e:Employee {{id: $id}})
        SET {set_clause}
        RETURN e
        """
        
        params = {"id": emp_id, "updated_at": now, **updates}
        result = await db_manager.get_single(query, params)

        if result:
            # Log audit event
            await AuditService.log_event(
                entity_type="EMPLOYEE",
                entity_id=emp_id,
                operation="UPDATE",
                changes=updates,
                changed_by="system"
            )
            # convert node to plain dict
            return node_to_dict(result)
        return None
    
    @staticmethod
    async def delete_employee(emp_id: str) -> bool:
        query = "MATCH (e:Employee {id: $id}) DETACH DELETE e"
        await db_manager.execute(query, {"id": emp_id})
        
        # Log audit event
        await AuditService.log_event(
            entity_type="EMPLOYEE",
            entity_id=emp_id,
            operation="DELETE",
            changes={},
            changed_by="system"
        )
        return True

class OrganizationService:
    @staticmethod
    async def create_organization(name: str, description: Optional[str] = None, location: Optional[str] = None) -> Dict:
        org_id = str(uuid.uuid4())
        now = datetime.utcnow().isoformat()
        
        query = """
        CREATE (o:Organization {
            id: $id,
            name: $name,
            description: $description,
            location: $location,
            created_at: $created_at,
            updated_at: $updated_at
        })
        RETURN o
        """
        
        result = await db_manager.execute(query, {
            "id": org_id,
            "name": name,
            "description": description,
            "location": location,
            "created_at": now,
            "updated_at": now
        })
        
        # Create audit event
        await AuditService.log_event(
            entity_type="ORGANIZATION",
            entity_id=org_id,
            operation="CREATE",
            changes={"name": name, "description": description, "location": location},
            changed_by="system"
        )
        
        return {"id": org_id, "name": name, "description": description, "location": location}
    
    @staticmethod
    async def get_organization(org_id: str) -> Optional[Dict]:
        query = "MATCH (o:Organization {id: $id}) RETURN o"
        result = await db_manager.get_single(query, {"id": org_id})
        if result:
            return node_to_dict(result)
        return None
    
    @staticmethod
    async def get_all_organizations() -> List[Dict]:
        query = "MATCH (o:Organization) RETURN o ORDER BY o.name"
        result = await db_manager.execute(query)
        return [node_to_dict(record[0]) for record in result]
    
    @staticmethod
    async def update_organization(org_id: str, updates: Dict) -> Optional[Dict]:
        now = datetime.utcnow().isoformat()
        
        set_clause = ", ".join([f"o.{k} = ${k}" for k in updates.keys()])
        set_clause += ", o.updated_at = $updated_at"
        
        query = f"""
        MATCH (o:Organization {{id: $id}})
        SET {set_clause}
        RETURN o
        """
        
        params = {"id": org_id, "updated_at": now, **updates}
        result = await db_manager.get_single(query, params)

        if result:
            # Log audit event
            await AuditService.log_event(
                entity_type="ORGANIZATION",
                entity_id=org_id,
                operation="UPDATE",
                changes=updates,
                changed_by="system"
            )
            return node_to_dict(result)
        return None
    
    @staticmethod
    async def delete_organization(org_id: str) -> bool:
        query = "MATCH (o:Organization {id: $id}) DETACH DELETE o"
        await db_manager.execute(query, {"id": org_id})
        
        # Log audit event
        await AuditService.log_event(
            entity_type="ORGANIZATION",
            entity_id=org_id,
            operation="DELETE",
            changes={},
            changed_by="system"
        )
        return True

class RelationshipService:
    @staticmethod
    async def create_relationship(employee_id: str, organization_id: str, role: str = "member") -> Dict:
        rel_id = str(uuid.uuid4())
        now = datetime.utcnow().isoformat()
        
        query = """
        MATCH (e:Employee {id: $emp_id}), (o:Organization {id: $org_id})
        CREATE (e)-[r:WORKS_FOR {
            id: $id,
            role: $role,
            created_at: $created_at,
            updated_at: $updated_at
        }]->(o)
        RETURN r
        """
        
        result = await db_manager.execute(query, {
            "id": rel_id,
            "emp_id": employee_id,
            "org_id": organization_id,
            "role": role,
            "created_at": now,
            "updated_at": now
        })
        
        # Log audit event
        await AuditService.log_event(
            entity_type="RELATIONSHIP",
            entity_id=rel_id,
            operation="CREATE",
            changes={"employee_id": employee_id, "organization_id": organization_id, "role": role},
            changed_by="system"
        )
        
        return {"id": rel_id, "employee_id": employee_id, "organization_id": organization_id, "role": role}
    
    @staticmethod
    async def get_all_relationships() -> List[Dict]:
        query = """
        MATCH (e:Employee)-[r:WORKS_FOR]->(o:Organization)
        RETURN {
            id: r.id,
            employee_id: e.id,
            employee_name: e.name,
            organization_id: o.id,
            organization_name: o.name,
            role: r.role,
            created_at: r.created_at,
            updated_at: r.updated_at
        } as rel
        """
        result = await db_manager.execute(query)
        return [record[0] for record in result]
    
    @staticmethod
    async def update_relationship(rel_id: str, role: str) -> bool:
        now = datetime.utcnow().isoformat()
        
        query = """
        MATCH ()-[r:WORKS_FOR {id: $id}]->()
        SET r.role = $role, r.updated_at = $updated_at
        RETURN r
        """
        
        result = await db_manager.get_single(query, {
            "id": rel_id,
            "role": role,
            "updated_at": now
        })
        
        if result:
            # Log audit event
            await AuditService.log_event(
                entity_type="RELATIONSHIP",
                entity_id=rel_id,
                operation="UPDATE",
                changes={"role": role},
                changed_by="system"
            )
            return True
        return False
    
    @staticmethod
    async def delete_relationship(rel_id: str) -> bool:
        query = "MATCH ()-[r:WORKS_FOR {id: $id}]->() DELETE r"
        await db_manager.execute(query, {"id": rel_id})
        
        # Log audit event
        await AuditService.log_event(
            entity_type="RELATIONSHIP",
            entity_id=rel_id,
            operation="DELETE",
            changes={},
            changed_by="system"
        )
        return True

class AuditService:
    @staticmethod
    async def log_event(entity_type: str, entity_id: str, operation: str, changes: Dict, changed_by: str):
        audit_id = str(uuid.uuid4())
        now = datetime.utcnow().isoformat()
        
        query = """
        CREATE (a:AuditEvent {
            id: $id,
            entity_type: $entity_type,
            entity_id: $entity_id,
            operation: $operation,
            changes: $changes,
            changed_by: $changed_by,
            timestamp: $timestamp,
            version: 0
        })
        """
        
        await db_manager.execute(query, {
            "id": audit_id,
            "entity_type": entity_type,
            "entity_id": entity_id,
            "operation": operation,
            "changes": json.dumps(changes),
            "changed_by": changed_by,
            "timestamp": now
        })
    
    @staticmethod
    async def get_entity_history(entity_id: str) -> List[Dict]:
        query = """
        MATCH (a:AuditEvent {entity_id: $entity_id})
        RETURN a
        ORDER BY a.timestamp DESC
        """
        result = await db_manager.execute(query, {"entity_id": entity_id})
        return [dict(record[0]) for record in result]
    
    @staticmethod
    async def get_all_events(limit: int = 100) -> List[Dict]:
        query = """
        MATCH (a:AuditEvent)
        RETURN a
        ORDER BY a.timestamp DESC
        LIMIT $limit
        """
        result = await db_manager.execute(query, {"limit": limit})
        return [dict(record[0]) for record in result]

class GraphService:
    @staticmethod
    async def get_full_graph():
        query = """
        MATCH (e:Employee), (o:Organization), (e)-[r:WORKS_FOR]->(o)
        RETURN {
            nodes: collect(DISTINCT {
                id: e.id,
                label: e.name,
                type: 'employee',
                properties: {name: e.name, email: e.email, title: e.title, department: e.department}
            }) + collect(DISTINCT {
                id: o.id,
                label: o.name,
                type: 'organization',
                properties: {name: o.name, description: o.description, location: o.location}
            }),
            edges: collect({
                source: e.id,
                target: o.id,
                label: r.role
            })
        } as graph
        """
        result = await db_manager.get_single(query)
        if result:
            return result
        return {"nodes": [], "edges": []}
    
    @staticmethod
    async def get_graph_at_timestamp(timestamp: str):
        """Get graph state at a specific point in time by replaying audit events"""
        query = """
        MATCH (a:AuditEvent)
        WHERE a.timestamp <= $timestamp
        RETURN a ORDER BY a.timestamp ASC
        """
        result = await db_manager.execute(query, {"timestamp": timestamp})
        
        if not result:
            return {"nodes": [], "edges": []}
        
        # Replay events to reconstruct state
        employees = {}      # id -> {name, email, title, department}
        organizations = {}  # id -> {name, description, location}
        relationships = {}  # id -> {employee_id, organization_id, role}
        
        for record in result:
            event = dict(record[0])
            entity_type = event.get("entity_type", "")
            entity_id = event.get("entity_id", "")
            operation = event.get("operation", "")
            changes_raw = event.get("changes", "{}")
            
            try:
                changes = json.loads(changes_raw) if isinstance(changes_raw, str) else (changes_raw or {})
            except (json.JSONDecodeError, TypeError):
                changes = {}
            
            if entity_type == "EMPLOYEE":
                if operation == "CREATE":
                    employees[entity_id] = {
                        "name": changes.get("name", "Unknown"),
                        "email": changes.get("email", ""),
                        "title": changes.get("title", ""),
                        "department": changes.get("department", ""),
                    }
                elif operation == "UPDATE" and entity_id in employees:
                    employees[entity_id].update(changes)
                elif operation == "DELETE":
                    employees.pop(entity_id, None)
                    # Also remove relationships involving this employee
                    relationships = {
                        rid: r for rid, r in relationships.items()
                        if r.get("employee_id") != entity_id
                    }
            
            elif entity_type == "ORGANIZATION":
                if operation == "CREATE":
                    organizations[entity_id] = {
                        "name": changes.get("name", "Unknown"),
                        "description": changes.get("description", ""),
                        "location": changes.get("location", ""),
                    }
                elif operation == "UPDATE" and entity_id in organizations:
                    organizations[entity_id].update(changes)
                elif operation == "DELETE":
                    organizations.pop(entity_id, None)
                    # Also remove relationships involving this org
                    relationships = {
                        rid: r for rid, r in relationships.items()
                        if r.get("organization_id") != entity_id
                    }
            
            elif entity_type == "RELATIONSHIP":
                if operation == "CREATE":
                    relationships[entity_id] = {
                        "employee_id": changes.get("employee_id", ""),
                        "organization_id": changes.get("organization_id", ""),
                        "role": changes.get("role", "member"),
                    }
                elif operation == "UPDATE" and entity_id in relationships:
                    relationships[entity_id].update(changes)
                elif operation == "DELETE":
                    relationships.pop(entity_id, None)
        
        # Build graph response
        nodes = []
        for eid, emp in employees.items():
            nodes.append({
                "id": eid,
                "label": emp.get("name", "Unknown"),
                "type": "employee",
                "properties": emp
            })
        for oid, org in organizations.items():
            nodes.append({
                "id": oid,
                "label": org.get("name", "Unknown"),
                "type": "organization",
                "properties": org
            })
        
        # Only include edges where both endpoints exist
        valid_ids = set(employees.keys()) | set(organizations.keys())
        edges = []
        for rid, rel in relationships.items():
            if rel.get("employee_id") in valid_ids and rel.get("organization_id") in valid_ids:
                edges.append({
                    "source": rel["employee_id"],
                    "target": rel["organization_id"],
                    "label": rel.get("role", "member")
                })
        
        return {"nodes": nodes, "edges": edges}
