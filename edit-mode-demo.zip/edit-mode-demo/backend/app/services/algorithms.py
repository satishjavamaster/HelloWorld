"""Algorithm implementations for the Planner subsystem.

Each algorithm is an async function that simulates long-running computation
via ``asyncio.sleep``.  The public entry-point :func:`run_algorithm`
dispatches to the correct implementation and keeps the
:class:`~app.services.job_manager.JobManager` updated throughout the
execution lifecycle.

Available algorithms
--------------------
- ``shortest_path``       – simulated shortest-path search.
- ``community_detection`` – simulated community / cluster detection.
- ``pagerank``            – simulated PageRank scoring.
"""

import asyncio
import random
from app.services.job_manager import job_manager, JobStatus


async def run_algorithm(job_id: str, algorithm: str, parameters: dict):
    """Dispatch and execute the requested algorithm.

    Updates the job status to ``RUNNING`` immediately, then to
    ``COMPLETED`` or ``FAILED`` once the algorithm finishes.

    Args:
        job_id: UUID of the job to update.
        algorithm: Algorithm identifier string.
        parameters: Algorithm-specific input dict.
    """
    try:
        await job_manager.update_status(job_id, JobStatus.RUNNING)

        if algorithm == "shortest_path":
            result = await _algo_shortest_path(parameters)
        elif algorithm == "community_detection":
            result = await _algo_community_detection(parameters)
        elif algorithm == "pagerank":
            result = await _algo_pagerank(parameters)
        else:
            raise ValueError(f"Unknown algorithm: {algorithm}")

        await job_manager.update_status(job_id, JobStatus.COMPLETED, result=result)
    except Exception as e:
        await job_manager.update_status(job_id, JobStatus.FAILED, error=str(e))


# --------------- stub algorithms (simulate long-running work) ---------------

async def _algo_shortest_path(params: dict) -> dict:
    """Simulated shortest path algorithm."""
    await asyncio.sleep(5)
    return {
        "algorithm": "shortest_path",
        "path": ["A", "C", "E", "G"],
        "cost": round(random.uniform(1, 20), 2),
        "nodes_explored": random.randint(10, 200),
    }


async def _algo_community_detection(params: dict) -> dict:
    """Simulated community detection algorithm."""
    await asyncio.sleep(8)
    communities = random.randint(2, 6)
    return {
        "algorithm": "community_detection",
        "communities_found": communities,
        "clusters": {f"cluster_{i}": random.randint(3, 15) for i in range(communities)},
    }


async def _algo_pagerank(params: dict) -> dict:
    """Simulated pagerank algorithm."""
    await asyncio.sleep(6)
    return {
        "algorithm": "pagerank",
        "top_nodes": [
            {"node": f"Node_{i}", "score": round(random.uniform(0, 1), 4)}
            for i in range(5)
        ],
        "iterations": random.randint(10, 50),
    }


# --------------- sync algorithms (fast, direct return) ---------------

SYNC_ALGORITHMS = {"node_count", "degree_summary", "density"}


def run_sync_algorithm(algorithm: str, parameters: dict) -> dict:
    """Execute a fast, synchronous algorithm and return the result directly.

    Args:
        algorithm: Algorithm identifier string.
        parameters: Algorithm-specific input dict.

    Raises:
        ValueError: If the algorithm is unknown.
    """
    if algorithm == "node_count":
        return _sync_node_count(parameters)
    elif algorithm == "degree_summary":
        return _sync_degree_summary(parameters)
    elif algorithm == "density":
        return _sync_density(parameters)
    else:
        raise ValueError(f"Unknown sync algorithm: {algorithm}")


def _sync_node_count(params: dict) -> dict:
    """Count nodes by type."""
    return {
        "algorithm": "node_count",
        "employees": random.randint(10, 100),
        "organizations": random.randint(2, 20),
    }


def _sync_degree_summary(params: dict) -> dict:
    """Basic degree statistics."""
    return {
        "algorithm": "degree_summary",
        "min_degree": random.randint(0, 2),
        "max_degree": random.randint(5, 20),
        "avg_degree": round(random.uniform(1, 8), 2),
    }


def _sync_density(params: dict) -> dict:
    """Graph density calculation."""
    return {
        "algorithm": "density",
        "density": round(random.uniform(0.01, 0.5), 4),
        "total_nodes": random.randint(10, 120),
        "total_edges": random.randint(5, 200),
    }
