from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import employees, organizations, relationships, history, planner
from app.services.database import init_db

app = FastAPI(title="OrgChart API", version="1.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize database
@app.on_event("startup")
async def startup():
    await init_db()

# Include routers
app.include_router(employees.router, prefix="/api/employees", tags=["employees"])
app.include_router(organizations.router, prefix="/api/organizations", tags=["organizations"])
app.include_router(relationships.router, prefix="/api/relationships", tags=["relationships"])
app.include_router(history.router, prefix="/api/history", tags=["history"])
app.include_router(planner.router, prefix="/api/planner", tags=["planner"])

@app.get("/")
async def root():
    return {"message": "OrgChart API is running"}

@app.get("/health")
async def health():
    return {"status": "healthy"}
