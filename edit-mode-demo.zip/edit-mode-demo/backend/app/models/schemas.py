from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime

class EmployeeBase(BaseModel):
    name: str
    email: str
    title: str
    department: Optional[str] = None

class EmployeeCreate(EmployeeBase):
    pass

class EmployeeUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[str] = None
    title: Optional[str] = None
    department: Optional[str] = None

class Employee(EmployeeBase):
    id: str
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class OrganizationBase(BaseModel):
    name: str
    description: Optional[str] = None
    location: Optional[str] = None

class OrganizationCreate(OrganizationBase):
    pass

class OrganizationUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    location: Optional[str] = None

class Organization(OrganizationBase):
    id: str
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class RelationshipBase(BaseModel):
    employee_id: str
    organization_id: str
    role: Optional[str] = "member"

class RelationshipCreate(RelationshipBase):
    pass

class RelationshipUpdate(BaseModel):
    role: Optional[str] = None

class Relationship(RelationshipBase):
    id: str
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class AuditEvent(BaseModel):
    id: str
    entity_type: str  # "EMPLOYEE", "ORGANIZATION", "RELATIONSHIP"
    entity_id: str
    operation: str  # "CREATE", "UPDATE", "DELETE"
    changes: Dict[str, Any]
    changed_by: str
    timestamp: datetime
    version: int

class GraphData(BaseModel):
    nodes: List[Dict[str, Any]]
    edges: List[Dict[str, Any]]
