from fastapi import APIRouter, HTTPException
from app.models.schemas import EmployeeCreate, EmployeeUpdate
from app.services.database import EmployeeService

router = APIRouter()

@router.post("/")
async def create_employee(employee: EmployeeCreate):
    """Create a new employee"""
    result = await EmployeeService.create_employee(
        name=employee.name,
        email=employee.email,
        title=employee.title,
        department=employee.department
    )
    return result

@router.get("/")
async def get_all_employees():
    """Get all employees"""
    employees = await EmployeeService.get_all_employees()
    return employees

@router.get("/{employee_id}")
async def get_employee(employee_id: str):
    """Get a specific employee"""
    employee = await EmployeeService.get_employee(employee_id)
    if not employee:
        raise HTTPException(status_code=404, detail="Employee not found")
    return employee

@router.put("/{employee_id}")
async def update_employee(employee_id: str, updates: EmployeeUpdate):
    """Update an employee"""
    update_dict = updates.dict(exclude_unset=True)
    if not update_dict:
        raise HTTPException(status_code=400, detail="No updates provided")
    
    result = await EmployeeService.update_employee(employee_id, update_dict)
    if not result:
        raise HTTPException(status_code=404, detail="Employee not found")
    return result

@router.delete("/{employee_id}")
async def delete_employee(employee_id: str):
    """Delete an employee"""
    success = await EmployeeService.delete_employee(employee_id)
    if not success:
        raise HTTPException(status_code=404, detail="Employee not found")
    return {"message": "Employee deleted successfully"}
