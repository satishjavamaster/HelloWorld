from fastapi import APIRouter, HTTPException
from app.models.schemas import OrganizationCreate, OrganizationUpdate
from app.services.database import OrganizationService

router = APIRouter()

@router.post("/")
async def create_organization(organization: OrganizationCreate):
    """Create a new organization"""
    result = await OrganizationService.create_organization(
        name=organization.name,
        description=organization.description,
        location=organization.location
    )
    return result

@router.get("/")
async def get_all_organizations():
    """Get all organizations"""
    organizations = await OrganizationService.get_all_organizations()
    return organizations

@router.get("/{org_id}")
async def get_organization(org_id: str):
    """Get a specific organization"""
    organization = await OrganizationService.get_organization(org_id)
    if not organization:
        raise HTTPException(status_code=404, detail="Organization not found")
    return organization

@router.put("/{org_id}")
async def update_organization(org_id: str, updates: OrganizationUpdate):
    """Update an organization"""
    update_dict = updates.dict(exclude_unset=True)
    if not update_dict:
        raise HTTPException(status_code=400, detail="No updates provided")
    
    result = await OrganizationService.update_organization(org_id, update_dict)
    if not result:
        raise HTTPException(status_code=404, detail="Organization not found")
    return result

@router.delete("/{org_id}")
async def delete_organization(org_id: str):
    """Delete an organization"""
    success = await OrganizationService.delete_organization(org_id)
    if not success:
        raise HTTPException(status_code=404, detail="Organization not found")
    return {"message": "Organization deleted successfully"}
