from fastapi import APIRouter, HTTPException
from app.models.schemas import RelationshipCreate, RelationshipUpdate
from app.services.database import RelationshipService

router = APIRouter()

@router.post("/")
async def create_relationship(relationship: RelationshipCreate):
    """Create a relationship between employee and organization"""
    result = await RelationshipService.create_relationship(
        employee_id=relationship.employee_id,
        organization_id=relationship.organization_id,
        role=relationship.role
    )
    return result

@router.get("/")
async def get_all_relationships():
    """Get all relationships"""
    relationships = await RelationshipService.get_all_relationships()
    return relationships

@router.put("/{rel_id}")
async def update_relationship(rel_id: str, updates: RelationshipUpdate):
    """Update a relationship"""
    success = await RelationshipService.update_relationship(rel_id, updates.role)
    if not success:
        raise HTTPException(status_code=404, detail="Relationship not found")
    return {"message": "Relationship updated successfully"}

@router.delete("/{rel_id}")
async def delete_relationship(rel_id: str):
    """Delete a relationship"""
    success = await RelationshipService.delete_relationship(rel_id)
    if not success:
        raise HTTPException(status_code=404, detail="Relationship not found")
    return {"message": "Relationship deleted successfully"}
