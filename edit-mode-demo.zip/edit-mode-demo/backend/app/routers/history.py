from fastapi import APIRouter, HTTPException
from app.services.database import AuditService, GraphService

router = APIRouter()

@router.get("/events")
async def get_all_events(limit: int = 100):
    """Get all audit events"""
    events = await AuditService.get_all_events(limit)
    return events

@router.get("/entity/{entity_id}")
async def get_entity_history(entity_id: str):
    """Get history for a specific entity"""
    history = await AuditService.get_entity_history(entity_id)
    if not history:
        raise HTTPException(status_code=404, detail="No history found for this entity")
    return history

@router.get("/graph")
async def get_graph():
    """Get current graph state"""
    graph = await GraphService.get_full_graph()
    return graph

@router.get("/graph/at/{timestamp}")
async def get_graph_at_timestamp(timestamp: str):
    """Get graph state at a specific timestamp"""
    graph = await GraphService.get_graph_at_timestamp(timestamp)
    return graph
