import asyncio
from app.services.database import db_manager, OrganizationService

async def test_org_service():
    """Test OrganizationService.create_organization"""
    await db_manager.connect()
    
    try:
        result = await OrganizationService.create_organization(
            name='Service Test Org',
            description='Service Test',
            location='Building F'
        )
        print('SUCCESS:', result)
    except Exception as e:
        import traceback
        print('ERROR:', type(e).__name__, str(e))
        traceback.print_exc()

asyncio.run(test_org_service())
