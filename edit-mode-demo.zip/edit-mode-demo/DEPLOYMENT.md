# Deployment Guide

## System Requirements

- Docker & Docker Compose (v20.10+)
- 4GB RAM minimum
- 10GB disk space
- Ports available: 4200, 7474, 7687, 8000

## Production Deployment

### 1. Environment Configuration

Create `.env` in the backend directory:
```bash
NEO4J_URI=bolt://neo4j:7687
NEO4J_USER=neo4j
NEO4J_PASSWORD=<strong-password-here>
```

### 2. Build and Deploy

```bash
# Build all images
docker-compose build

# Start services
docker-compose up -d

# Check status
docker-compose ps

# View logs
docker-compose logs -f backend
```

### 3. Verify Installation

```bash
# Check API health
curl http://localhost:8000/health

# Check Neo4j connection
curl http://localhost:7474

# Access frontend
open http://localhost:4200
```

## Docker Compose Services

### Neo4j
- **Port**: 7474 (HTTP), 7687 (Bolt)
- **Credentials**: neo4j / password123
- **Volume**: neo4j_data (persists database)

### Backend (FastAPI)
- **Port**: 8000
- **Auto-reload**: Enabled in development
- **Framework**: FastAPI + Uvicorn
- **Database**: Async Neo4j driver

### Frontend (Angular)
- **Port**: 4200
- **CLI**: ng serve with hot reload
- **Build**: Production build in Docker

## Scaling Considerations

### Vertical Scaling
- Increase Docker memory limits
- Adjust Neo4j heap size in docker-compose.yml

### Horizontal Scaling
- Run multiple API instances behind load balancer
- Use Neo4j clustering (Enterprise Edition)
- Implement caching layer (Redis)

## Backup & Recovery

### Backup Neo4j Data

```bash
docker-compose exec neo4j neo4j-admin database dump neo4j /backups/neo4j.dump
docker cp orgchart-neo4j:/backups/neo4j.dump ./
```

### Restore from Backup

```bash
docker-compose exec neo4j neo4j-admin database load neo4j /backups/neo4j.dump --overwrite-destination=true
```

## Monitoring

### View Logs

```bash
# All services
docker-compose logs

# Specific service
docker-compose logs backend
docker-compose logs neo4j

# Follow logs
docker-compose logs -f
```

### Health Endpoints

```bash
# Backend health
curl localhost:8000/health

# Neo4j health
curl http://localhost:7474/db/neo4j/
```

## Development Tips

### Rebuild After Code Changes

```bash
docker-compose down
docker-compose build --no-cache
docker-compose up
```

### Access Database Directly

```bash
docker-compose exec neo4j cypher-shell -u neo4j -p password123
```

### View Database Stats

```bash
curl -X GET http://localhost:8000/api/employees/
curl -X GET http://localhost:8000/api/organizations/
curl -X GET http://localhost:8000/api/history/events
```

## Troubleshooting

### Port Already in Use

If ports are in use, either:
1. Stop running containers
2. Change Docker Compose port mapping

### Neo4j Won't Start

```bash
# Check logs
docker-compose logs neo4j

# Restart Neo4j
docker-compose restart neo4j

# Reset (WARNING: loses data)
docker-compose down -v
docker-compose up
```

### API Connection Issues

```bash
# Check API logs
docker-compose logs backend

# Check network
docker-compose ps
docker network ls
```

### Frontend Not Loading

```bash
# Check frontend logs
docker-compose logs frontend

# Clear npm cache
docker-compose exec frontend npm cache clean --force
docker-compose restart frontend
```

## Security Notes

- Change default Neo4j password in production
- Use environment variables for sensitive configs
- Implement API authentication (JWT recommended)
- Enable HTTPS/TLS in production
- Add CORS restrictions

## Performance Optimization

1. **Database Indexes**: Already created in init_db()
2. **Query Optimization**: Use provided Cypher queries
3. **Caching**: Add Redis for frequent queries
4. **API Rate Limiting**: Implement in FastAPI
5. **Frontend Optimization**: Use Angular AOT compilation

## Maintenance

### Regular Tasks

- Monitor disk usage
- Check log files
- Review audit events
- Update dependencies
- Backup database daily

### Update Procedure

```bash
docker-compose pull
docker-compose up -d
docker image prune
```
