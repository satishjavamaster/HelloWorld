# Architecture Documentation

## System Overview

```
┌─────────────────────────────────────────────────────────────┐
│                     Browser / Client                         │
└──────────────────────────┬──────────────────────────────────┘
                           │
                    HTTP/REST (port 4200)
                           │
┌──────────────────────────▼──────────────────────────────────┐
│                   Angular Frontend                           │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Components:                                           │ │
│  │  - Dashboard (statistics overview)                     │ │
│  │  - EmployeeList (CRUD with edit mode)                 │ │
│  │  - OrganizationList (CRUD with edit mode)             │ │
│  │  - GraphVisualizer (D3.js force-directed graph)        │ │
│  │  - Timeline (audit trail & history)                   │ │
│  │  - Navbar (routing)                                   │ │
│  └────────────────────────────────────────────────────────┘ │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Services:                                              │ │
│  │  - ApiService (HTTP communication with backend)        │ │
│  └────────────────────────────────────────────────────────┘ │
└──────────────────────────┬──────────────────────────────────┘
                           │
                    HTTP/REST (port 8000)
                           │
┌──────────────────────────▼──────────────────────────────────┐
│                   FastAPI Backend                           │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Routers:                                               │ │
│  │  - /api/employees (CRUD operations)                    │ │
│  │  - /api/organizations (CRUD operations)                │ │
│  │  - /api/relationships (manage associations)            │ │
│  │  - /api/history (audit & graph state)                  │ │
│  └────────────────────────────────────────────────────────┘ │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Services:                                              │ │
│  │  - EmployeeService (business logic)                    │ │
│  │  - OrganizationService (business logic)                │ │
│  │  - RelationshipService (association logic)             │ │
│  │  - AuditService (event logging)                        │ │
│  │  - GraphService (graph data retrieval)                 │ │
│  │  - DatabaseManager (Neo4j driver)                      │ │
│  └────────────────────────────────────────────────────────┘ │
└──────────────────────────┬──────────────────────────────────┘
                           │
                    Bolt Protocol (port 7687)
                           │
┌──────────────────────────▼──────────────────────────────────┐
│                   Neo4j Database                            │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Nodes:                                                 │ │
│  │  - Employee (id, name, email, title, department)       │ │
│  │  - Organization (id, name, description, location)      │ │
│  │  - AuditEvent (entity_type, operation, timestamp)      │ │
│  │  - GraphSnapshot (timestamp, payload)                   │ │
│  └────────────────────────────────────────────────────────┘ │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Relationships:                                         │ │
│  │  - Employee -[WORKS_FOR]-> Organization (role)         │ │
│  └────────────────────────────────────────────────────────┘ │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Indexes & Constraints:                                 │ │
│  │  - UNIQUE Employee.id, Organization.id, AuditEvent.id  │ │
│  │  - UNIQUE GraphSnapshot.timestamp                       │ │
│  │  - INDEX Employee.email, Organization.name             │ │
│  └────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────┘
```

## Data Flow

### Create Entity (Employee/Organization)

```
1. User fills form in Angular → Component
2. Component calls ApiService.createEmployee()
3. ApiService sends POST request to FastAPI
4. FastAPI router validates data
5. EmployeeService generates UUID, creates node
6. Neo4j creates Employee node with properties
7. AuditService logs CREATE event
8. Response returned with created entity
9. Component updates employee list
10. Angular UI refreshed
```

### Edit Entity

```
1. User clicks Edit button → Form populated
2. User modifies fields → Form state updated
3. User submits → ApiService.updateEmployee()
4. FastAPI router validates updates
5. EmployeeService builds SET clause, updates node
6. Neo4j updates Employee properties
7. AuditService logs UPDATE event with changes
8. Response returned with updated entity
9. Component refreshes list
10. UI shows updated data + history event
```

### Create Relationship

```
1. Select Employee + Organization → ApiService
2. FastAPI matches both entities
3. RelationshipService creates WORKS_FOR relationship
4. Neo4j creates relationship with role property
5. AuditService logs event
6. Graph visualization refreshed with new edge
```

### View Graph

```
1. User navigates to Graph View
2. Component calls ApiService.getFullGraph()
3. FastAPI GraphService runs Cypher query
4. Neo4j returns nodes + relationships
5. D3.js initializes force-directed simulation
6. Nodes rendered as circles with labels
7. Edges rendered as lines
8. Drag/zoom interactions enabled
9. Updates on any CRUD operation
```

### View Timeline

```
1. User navigates to Timeline
2. Component calls ApiService.getAuditEvents()
3. FastAPI AuditService queries all AuditEvents
4. Events sorted by timestamp DESC
5. Component filters by type/operation
6. UI displays events with details
7. User can view graph state at any timestamp
```

### Replay Historical Graph (Snapshot + Delta)

```
1. Timeline requests /api/history/graph/at/{timestamp}
2. GraphService reads latest GraphSnapshot where snapshot.timestamp <= timestamp
3. If snapshot exists, load payload as base state
4. Query AuditEvent records in (snapshot.timestamp, timestamp]
5. Replay events in ascending order via _apply_event_to_state(...)
6. Build response graph (nodes + edges) from final in-memory state
7. Optionally persist a new snapshot (time-based threshold)
```

This avoids full-history replay for every request and keeps replay cost proportional to events since the last snapshot.

## Key Design Decisions

### Why Neo4j?
- Natural graph representation of employee-org relationships
- Efficient relationship queries
- Built-in constraints and indexes
- Support for audit trail (AuditEvent nodes)
- Powerful query language (Cypher)

### Why FastAPI?
- Async/await support for I/O efficiency
- Built-in OpenAPI documentation
- Pydantic for data validation
- Better performance than Flask/Django for this use case
- Native async Neo4j driver support

### Why Angular?
- Component-based architecture
- Built-in dependency injection
- Strong typing with TypeScript
- Excellent CLI tools
- Native HTTP client
- Large ecosystem

### Why D3.js?
- Industry standard for data visualization
- Force-directed graph perfect for org structures
- Interactive features (drag, zoom, hover)
- Highly customizable
- Canvas/SVG rendering

## Audit Trail Implementation

Every change is logged as an AuditEvent node:

```cypher
CREATE (a:AuditEvent {
    id: uuid,
    entity_type: "EMPLOYEE|ORGANIZATION|RELATIONSHIP",
    entity_id: reference-to-entity,
    operation: "CREATE|UPDATE|DELETE",
    changes: {old_key: new_value},
    changed_by: "system|user",
    timestamp: iso-datetime,
    version: incremental
})
```

This enables:
- Complete history per entity
- Timeline visualization
- Replay capability (foundation)
- Compliance tracking

## Snapshot Architecture

### Purpose
- Reduce historical replay latency for larger datasets
- Keep replay deterministic while preserving event-sourced behavior

### Storage Model
- Snapshot is stored as a Neo4j node: `(:GraphSnapshot {timestamp, payload, ...})`
- `payload` is a serialized JSON object containing:
    - `employees` map
    - `organizations` map
    - `relationships` map

### Trigger & Write Policy
- Snapshot write is executed during `get_graph_at_timestamp(...)`
- A new snapshot is persisted only when:
    - At least one event was replayed, and
    - Time delta since previous snapshot is at least 300 seconds

### Determinism Rules
- Snapshot selection uses latest snapshot at or before target timestamp
- Replay query uses strict window: `event.timestamp > snapshot_timestamp AND <= requested_timestamp`
- Replay order is ascending by timestamp

### Operational Notes
- Works with ISO-8601 UTC timestamps
- Snapshot payload increases Neo4j storage; tradeoff is lower query-time compute
- If payload parsing fails, system safely falls back to empty state + replay

## Edit Mode Pattern

Frontend implements dedicated edit mode:

```typescript
editMode = false  // view mode
selectedEntity = null
formData = {}

// Switch to edit
edit(entity) {
    editMode = true
    selectedEntity = entity
    formData = {...entity}
}

// Save changes
onSubmit() {
    if (selectedEntity) {
        // UPDATE
        apiService.updateEntity(formData)
    } else {
        // CREATE
        apiService.createEntity(formData)
    }
    editMode = false
}

// Cancel
cancelEdit() {
    editMode = false
    selectedEntity = null
}
```

Benefits:
- Clear visual separation
- No accidental edits
- Form state isolated
- Easy to add validation
- Can extend with drafts/rollback

## Performance Characteristics

### Reads (O(1) to O(n))
- Get single employee: O(1) indexed lookup
- Get all employees: O(n) scan + sort
- Get graph: O(n+m) where m=relationships
- Get timeline: O(n) scan + sort
- Get graph at timestamp with snapshot: O(k) where k=events since latest snapshot (plus snapshot load)

### Writes (O(1))
- Create node: O(1) write
- Update node: O(1) indexed write
- Create relationship: O(1) reference + write
- Log event: O(1) write + append

### Queries
- Most common paths use indexes
- Cypher planner optimizes traversals
- No N+1 problems with proper queries
- Potential bottleneck: large timeline queries

## Future Scalability

### Horizontal Scaling
- Multiple API instances with load balancer
- Shared Neo4j cluster (Enterprise)
- Redis cache layer
- Message queue for bulk ops

### Optimization
- Graph results caching
- Pagination for large lists
- Query result limiting
- Index additional properties

### Features
- Full-text search
- Complex relationship queries
- Recommendation engine
- Analytics dashboard
- Real-time updates (WebSockets)
