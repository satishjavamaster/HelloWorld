# OrgChart - Employee & Organization Management System

A full-stack application for managing employees, organizations, and their relationships with historical tracking and D3 visualization.

## Architecture

- **Frontend**: Angular 17 with D3.js visualization
- **Backend**: Python FastAPI with async/await
- **Database**: Neo4j graph database with audit trail
- **Deployment**: Docker Compose

## Features

- **Dashboard**: Overview statistics
- **Employee Management**: Create, read, update, delete employees with edit mode
- **Organization Management**: Manage organizations with details
- **Relationship Mapping**: Create associations between employees and organizations
- **Graph Visualization**: D3-based visualization of employee-org relationships
- **Edit History & Timeline**: Complete audit trail of all changes
- **Historical Replay**: View graph state at any point in time (foundation for replay feature)
- **Snapshot-Accelerated Replay**: Rebuild historical graph state using latest snapshot + incremental events

## Project Structure

```
edit-mode-demo/
├── docker-compose.yml        # Services orchestration
├── backend/                  # FastAPI application
│   ├── app/
│   │   ├── main.py          # FastAPI app initialization
│   │   ├── config.py        # Configuration
│   │   ├── models/          # Pydantic schemas
│   │   ├── services/        # Database services
│   │   └── routers/         # API endpoints
│   ├── Dockerfile
│   └── requirements.txt
├── frontend/                # Angular application
│   ├── src/
│   │   ├── app/
│   │   │   ├── components/  # Angular components
│   │   │   ├── services/    # API integration
│   │   │   └── app.routes.ts
│   │   └── main.ts
│   ├── Dockerfile
│   └── package.json
├── neo4j-init/             # Neo4j initialization scripts
└── README.md
```

## Getting Started

### Prerequisites

- Docker & Docker Compose
- Port 7474, 7687 (Neo4j), 8000 (API), 4200 (Angular) available

### Installation & Running

1. **Build and start all services:**
```bash
docker-compose up --build
```

2. **Access the application:**
   - Frontend: http://localhost:4200
   - API: http://localhost:8000
   - Neo4j Browser: http://localhost:7474 (user: neo4j, pwd: password123)

### Manual Testing

1. Create some employees via the Angular UI (Employees page)
2. Create organizations
3. Create relationships between them
4. View the D3 graph visualization
5. Check the timeline for audit events
6. Edit entities and see changes reflected in history

## API Endpoints

### Employees
- `GET /api/employees/` - List all employees
- `POST /api/employees/` - Create employee
- `GET /api/employees/{id}` - Get employee details
- `PUT /api/employees/{id}` - Update employee
- `DELETE /api/employees/{id}` - Delete employee

### Organizations
- `GET /api/organizations/` - List all organizations
- `POST /api/organizations/` - Create organization
- `GET /api/organizations/{id}` - Get organization details
- `PUT /api/organizations/{id}` - Update organization
- `DELETE /api/organizations/{id}` - Delete organization

### Relationships
- `GET /api/relationships/` - List all relationships
- `POST /api/relationships/` - Create relationship
- `PUT /api/relationships/{id}` - Update relationship role
- `DELETE /api/relationships/{id}` - Delete relationship

### History & Graph
- `GET /api/history/events` - Get audit events
- `GET /api/history/entity/{id}` - Get entity history
- `GET /api/history/graph` - Get current graph state
- `GET /api/history/graph/at/{timestamp}` - Get graph state at specific time

## Snapshot Replay Logic (Reference)

Historical graph reconstruction (`GET /api/history/graph/at/{timestamp}`) uses a **snapshot + delta replay** strategy in `GraphService`:

1. Find latest `GraphSnapshot` with `snapshot.timestamp <= requested_timestamp`
2. Load snapshot payload (employees, organizations, relationships) as in-memory state
3. Query `AuditEvent` records only in `(snapshot_timestamp, requested_timestamp]`
4. Replay each event in ascending timestamp order
5. Convert final state to `{nodes, edges}` response
6. Persist a new snapshot periodically (5-minute minimum interval when replay occurred)

If no snapshot exists, replay starts from an empty state and applies all events up to the requested timestamp.

### Verify Snapshot Creation

After calling `GET /api/history/graph/at/{timestamp}`, verify snapshots in Neo4j:

```bash
docker exec orgchart-neo4j cypher-shell -u neo4j -p password123 "MATCH (s:GraphSnapshot) RETURN count(s) AS snapshots, max(s.timestamp) AS latest"
```

Inspect the latest snapshot metadata:

```bash
docker exec orgchart-neo4j cypher-shell -u neo4j -p password123 "MATCH (s:GraphSnapshot) RETURN s.timestamp AS ts, size(s.payload) AS payload_bytes ORDER BY s.timestamp DESC LIMIT 1"
```

### Snapshot FAQs

**When is a snapshot created?**
- During `GET /api/history/graph/at/{timestamp}` processing.
- A snapshot is written only if at least one event was replayed.
- If a prior snapshot exists, the new snapshot is written only when the time gap is at least 300 seconds.

**Why didn’t a new snapshot appear?**
- No events existed in the replay window.
- The requested timestamp is too close to the latest snapshot (< 300 seconds).
- The same timestamp was requested again (same snapshot key).

**How can I clean up old snapshots?**
- Keep latest N snapshots:

```bash
docker exec orgchart-neo4j cypher-shell -u neo4j -p password123 "MATCH (s:GraphSnapshot) WITH s ORDER BY s.timestamp DESC SKIP 100 DETACH DELETE s"
```

- Delete snapshots older than a cutoff timestamp:

```bash
docker exec orgchart-neo4j cypher-shell -u neo4j -p password123 "MATCH (s:GraphSnapshot) WHERE s.timestamp < '2026-01-01T00:00:00' DETACH DELETE s"
```

## Database Schema (Neo4j)

### Nodes
- `Employee`: name, email, title, department, id, created_at, updated_at
- `Organization`: name, description, location, id, created_at, updated_at
- `AuditEvent`: entity_type, entity_id, operation, changes, changed_by, timestamp, version
- `GraphSnapshot`: timestamp, payload (JSON state), id, created_at, updated_at

### Relationships
- `Employee -[WORKS_FOR]-> Organization`: role (member/manager/etc)

### Indexes
- Employee.id (UNIQUE)
- Organization.id (UNIQUE)
- AuditEvent.id (UNIQUE)
- GraphSnapshot.timestamp (UNIQUE)
- Employee.email
- Organization.name

## Frontend Routes

- `/` - Dashboard
- `/employees` - Employee management
- `/organizations` - Organization management
- `/graph` - D3 graph visualization
- `/timeline` - Edit history & timeline

## Features Implemented

✅ Dashboard with statistics
✅ Employee CRUD with edit mode
✅ Organization CRUD with edit mode
✅ Relationship management
✅ D3 force-directed graph visualization
✅ Audit trail with timestamp
✅ Timeline view with filters
✅ Edit history per entity
✅ Docker Compose setup
✅ RESTful API with FastAPI

## Future Enhancements

- Enhanced timeline replay with animation
- Graph state comparison between timestamps
- Export/import functionality
- Advanced search and filtering
- User authentication and authorization
- Analytics dashboard
- Real-time updates with WebSockets
- Bulk operations
- Data validation rules
- Performance optimization for large datasets

## Troubleshooting

### Neo4j Connection Issues
Check if Neo4j is healthy:
```bash
docker-compose ps
docker-compose logs neo4j
```

### API Not Responding
Check backend logs:
```bash
docker-compose logs backend
```

### Frontend Not Loading
Check frontend build:
```bash
docker-compose logs frontend
```

### Docker Issues
Rebuild containers:
```bash
docker-compose down
docker-compose up --build
```

## Development Notes

- Backend uses async Neo4j driver for performance
- Audit events are logged for all changes
- D3 visualization supports drag/zoom interactions
- Edit mode separates viewing from editing concerns
- All timestamps are UTC-based ISO format

## License

MIT
