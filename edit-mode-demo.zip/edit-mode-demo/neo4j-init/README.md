# Neo4j connection setup
# Install Neo4j:
# brew install neo4j  (Mac)
# Or download from: https://neo4j.com/download/

# Default credentials:
# Username: neo4j
# Password: password123

# Browser access: http://localhost:7474
# Bolt connection: bolt://localhost:7687
